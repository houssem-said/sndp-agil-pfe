import React from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import AdminDashboard from "./pages/AdminDashboard.jsx";
import Login from "./pages/Login.jsx";
import Register from "./pages/Register.jsx";
import OperateurProfile from "./pages/OperateurProfile.jsx";
import AdminProfile from "./pages/AdminProfile.jsx";
import AdminUsers from "./pages/AdminUsers.jsx";
import OperateurDashboard from "./pages/OperateurDashboard.jsx";
import ClientDashboard from "./pages/ClientDashboard.jsx";
import Home from "./pages/Home.jsx";

function RequireRole({ children, allowedRoles }) {
    const user = JSON.parse(localStorage.getItem("user"));

    if (!user) {
        // Pas connecté, on redirige vers login
        return <Navigate to="/login" replace />;
    }

    if (!allowedRoles.includes(user.role)) {
        // Pas le bon rôle, redirection vers la page d'accueil
        return <Navigate to="/" replace />;
    }

    // Accès autorisé
    return children;
}

function App() {
    return (
        <Router>
            <Routes>
                {/* Accueil */}
                <Route path="/" element={<Home />} />

                {/* Pages publiques */}
                <Route path="/login" element={<Login />} />
                <Route path="/register" element={<Register />} />

                {/* Admin uniquement */}
                <Route
                    path="/admin-dashboard"
                    element={
                        <RequireRole allowedRoles={["ADMIN"]}>
                            <AdminDashboard />
                        </RequireRole>
                    }
                />
                <Route
                    path="/admin-profile"
                    element={
                        <RequireRole allowedRoles={["ADMIN"]}>
                            <AdminProfile />
                        </RequireRole>
                    }
                />
                <Route
                    path="/admin-users"
                    element={
                        <RequireRole allowedRoles={["ADMIN"]}>
                            <AdminUsers />
                        </RequireRole>
                    }
                />

                {/* Opérateur uniquement */}
                <Route
                    path="/operateur-dashboard"
                    element={
                        <RequireRole allowedRoles={["OPERATEUR"]}>
                            <OperateurDashboard />
                        </RequireRole>
                    }
                />
                <Route
                    path="/operateur/profile"
                    element={
                        <RequireRole allowedRoles={["OPERATEUR"]}>
                            <OperateurProfile />
                        </RequireRole>
                    }
                />

                {/* Client uniquement */}
                <Route
                    path="/client-dashboard"
                    element={
                        <RequireRole allowedRoles={["USER"]}>
                            <ClientDashboard />
                        </RequireRole>
                    }
                />
            </Routes>
        </Router>
    );
}

export default App;
