import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

export default function Register() {
    const navigate = useNavigate();

    // État local pour stocker les données du formulaire
    const [formData, setFormData] = useState({
        fullname: "",
        email: "",
        password: "",
        confirmPassword: "",
        telephone: ""
    });

    // État pour gérer les messages d’erreur et le chargement
    const [error, setError] = useState("");
    const [loading, setLoading] = useState(false);

    // Mise à jour du formulaire à chaque saisie dans un champ
    const handleChange = (e) => {
        setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
    };

    // Soumission du formulaire
    const handleSubmit = async (e) => {
        e.preventDefault();
        setError(""); // Réinitialiser les erreurs précédentes

        // Vérification : mot de passe et confirmation identiques
        if (formData.password !== formData.confirmPassword) {
            setError("Les mots de passe ne correspondent pas");
            return;
        }

        // Vérification : champ téléphone obligatoire
        if (!formData.telephone) {
            setError("Le téléphone est requis");
            return;
        }

        setLoading(true); // Activation du spinner/bouton désactivé

        try {
            // Envoi des données au backend pour inscription
            const res = await fetch("/api/auth/register", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    nom: formData.fullname,
                    email: formData.email,
                    motDePasse: formData.password,
                    role: "USER", // Enregistrement par défaut en tant que client
                    telephone: formData.telephone
                }),
            });

            // Gestion des erreurs retournées par le backend
            if (!res.ok) {
                const data = await res.json();
                throw new Error(data.message || "Erreur lors de l'inscription");
            }

            // Succès : redirection vers la page de connexion
            const data = await res.json();
            alert("Inscription réussie ! Vous pouvez maintenant vous connecter.");
            navigate("/login");
        } catch (err) {
            setError(err.message);
        } finally {
            setLoading(false); // Arrêter le spinner
        }
    };

    // ======= Affichage de la page =======
    return (
        <div
            className="min-h-screen bg-black bg-cover bg-center flex items-center justify-center"
            style={{ backgroundImage: "url('/images/acc.webp')" }}
        >
            <div className="bg-gray-900 bg-opacity-90 p-10 rounded-xl shadow-lg max-w-md w-full text-center text-white">
                <img src="/images/logo.gif" alt="Logo Agile" className="mx-auto w-24 mb-6" />
                <h2 className="text-yellow-400 text-3xl font-bold mb-8">Inscription</h2>

                {/* Formulaire d'inscription */}
                <form onSubmit={handleSubmit}>
                    {/* Champ Nom complet */}
                    <label htmlFor="fullname" className="block text-left text-white mb-1 font-medium">
                        Nom complet
                    </label>
                    <input
                        type="text"
                        id="fullname"
                        name="fullname"
                        placeholder="Jean Dupont"
                        value={formData.fullname}
                        onChange={handleChange}
                        required
                        className="w-full p-3 rounded-md bg-gray-800 text-white mb-6 focus:outline-yellow-400"
                    />

                    {/* Champ Email */}
                    <label htmlFor="email" className="block text-left text-white mb-1 font-medium">
                        Adresse e-mail
                    </label>
                    <input
                        type="email"
                        id="email"
                        name="email"
                        placeholder="exemple@domaine.com"
                        value={formData.email}
                        onChange={handleChange}
                        required
                        className="w-full p-3 rounded-md bg-gray-800 text-white mb-6 focus:outline-yellow-400"
                    />

                    {/* Champ Téléphone */}
                    <label htmlFor="telephone" className="block text-left text-white mb-1 font-medium">
                        Téléphone
                    </label>
                    <input
                        type="tel"
                        id="telephone"
                        name="telephone"
                        placeholder="--------"
                        value={formData.telephone}
                        onChange={handleChange}
                        required
                        className="w-full p-3 rounded-md bg-gray-800 text-white mb-6 focus:outline-yellow-400"
                    />

                    {/* Champ Mot de passe */}
                    <label htmlFor="password" className="block text-left text-white mb-1 font-medium">
                        Mot de passe
                    </label>
                    <input
                        type="password"
                        id="password"
                        name="password"
                        placeholder="********"
                        value={formData.password}
                        onChange={handleChange}
                        required
                        className="w-full p-3 rounded-md bg-gray-800 text-white mb-6 focus:outline-yellow-400"
                    />

                    {/* Champ Confirmation mot de passe */}
                    <label htmlFor="confirmPassword" className="block text-left text-white mb-1 font-medium">
                        Confirmer mot de passe
                    </label>
                    <input
                        type="password"
                        id="confirmPassword"
                        name="confirmPassword"
                        placeholder="********"
                        value={formData.confirmPassword}
                        onChange={handleChange}
                        required
                        className="w-full p-3 rounded-md bg-gray-800 text-white mb-6 focus:outline-yellow-400"
                    />

                    {/* Message d'erreur éventuel */}
                    {error && <p className="text-red-500 mb-4">{error}</p>}

                    {/* Bouton d'inscription */}
                    <button
                        type="submit"
                        disabled={loading}
                        className="w-full py-3 bg-yellow-400 text-black font-bold rounded-md hover:bg-yellow-500 transition disabled:opacity-50"
                    >
                        {loading ? "Inscription en cours..." : "S'inscrire"}
                    </button>

                    {/* Liens vers autres pages */}
                    <div className="mt-6 text-yellow-400 space-y-2">
                        <p>
                            Déjà un compte ?{" "}
                            <Link to="/login" className="underline hover:text-yellow-300">
                                Se connecter
                            </Link>
                        </p>
                        <p>
                            <Link to="/" className="underline hover:text-yellow-300">
                                ← Retour à l'accueil
                            </Link>
                        </p>
                    </div>
                </form>
            </div>
        </div>
    );
}
