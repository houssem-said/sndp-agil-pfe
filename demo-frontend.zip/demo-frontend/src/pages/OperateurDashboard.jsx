import React, { useEffect, useState, useRef } from "react";
import { useNavigate } from "react-router-dom";

export default function OperateurDashboard() {
    const navigate = useNavigate();

    // État pour gérer l'ouverture du menu utilisateur
    const [submenuOpen, setSubmenuOpen] = useState(false);
    const submenuRef = useRef(null);

    // Onglet actif (file d’attente ou profil)
    const [tab, setTab] = useState("file");

    // Informations de l'opérateur connecté
    const [user, setUser] = useState(null);

    // Dernier ticket appelé (affiché visuellement)
    const [dernierAppel, setDernierAppel] = useState(null);

    // Formulaire pour modifier les infos du profil
    const [form, setForm] = useState({ nom: "", email: "", telephone: "", password: "" });

    // État pour afficher une notification temporaire (toast)
    const [toast, setToast] = useState(null);

    // Indique si les données utilisateur sont en cours de chargement
    const [loading, setLoading] = useState(false);

    // Indique si un ticket est en cours d’appel (désactive le bouton)
    const [callingTicket, setCallingTicket] = useState(false);

    // Liste des tickets non encore appelés pour ce guichet
    const ticketsEnAttente = user?.guichet?.tickets?.filter(t => !t.appele) || [];

    /**
     * Fonction de chargement de l’utilisateur depuis l’API
     * Recharge les données à intervalle régulier
     */
    const loadUser = async () => {
        const localUser = JSON.parse(localStorage.getItem("user"));
        if (!localUser) {
            navigate("/login");
            return;
        }
        try {
            setLoading(true);
            const res = await fetch(`/api/users/${localUser.id}`);
            if (!res.ok) throw new Error("Erreur récupération utilisateur");

            const data = await res.json();
            setUser(data);

            // Préremplissage du formulaire avec les infos de l'utilisateur
            setForm({
                nom: data.nom || "",
                email: data.email || "",
                telephone: data.telephone || "",
                password: "",
            });

            localStorage.setItem("user", JSON.stringify(data));
        } catch (error) {
            console.error(error);
            showToast("Erreur chargement données utilisateur");
            // Fallback avec données locales
            setUser(localUser);
            setForm({
                nom: localUser.nom || "",
                email: localUser.email || "",
                telephone: localUser.telephone || "",
                password: "",
            });
        } finally {
            setLoading(false);
        }
    };

    // Initialisation au montage du composant
    useEffect(() => {
        loadUser();

        // Actualisation automatique toutes les 3 minutes
        const intervalId = setInterval(() => {
            loadUser();
        }, 180000);

        return () => clearInterval(intervalId);
    }, [navigate]);

    /**
     * Appelle le ticket suivant via l’API
     * Met à jour la file localement et affiche une alerte sonore
     */
    const appelerSuivant = async () => {
        if (!user || !user.guichet) return;

        setCallingTicket(true);
        try {
            const res = await fetch(`/api/tickets/next?guichetId=${user.guichet.id}`, { method: "POST" });

            if (!res.ok) {
                showToast("Erreur serveur lors de l'appel du ticket");
                setCallingTicket(false);
                return;
            }

            const ticket = await res.json();

            if (!ticket) {
                showToast("Aucun ticket en attente.");
                setDernierAppel(null);
            } else {
                setDernierAppel(ticket);
                showToast(`Ticket ${ticket.numero} appelé`);
                playAlertSound();

                // Mise à jour locale des tickets
                const updatedTickets = (user.guichet.tickets || []).filter(t => t.id !== ticket.id);
                const updatedUser = {
                    ...user,
                    guichet: {
                        ...user.guichet,
                        tickets: updatedTickets,
                    },
                };
                setUser(updatedUser);
                localStorage.setItem("user", JSON.stringify(updatedUser));
            }
        } catch (error) {
            console.error(error);
            showToast("Erreur réseau");
        } finally {
            setCallingTicket(false);
        }
    };

    // Lecture d'un son d'alerte après appel ticket
    const playAlertSound = () => {
        const audio = new Audio("/alert/alert.mp3");
        audio.play().catch(() => {}); // ignore les erreurs
    };

    // Déconnexion de l'opérateur
    const handleLogout = () => {
        localStorage.removeItem("user");
        navigate("/login");
    };

    // Gestion du changement dans le formulaire de profil
    const handleChange = (e) => {
        setForm({ ...form, [e.target.name]: e.target.value });
    };

    // Soumission du formulaire de modification de profil
    const handleUpdateProfile = async (e) => {
        e.preventDefault();
        if (!user) return;

        const updated = {
            ...user,
            nom: form.nom,
            email: form.email,
            telephone: form.telephone,
            ...(form.password ? { motDePasse: form.password } : {}),
        };

        try {
            const res = await fetch(`/api/users/${user.id}`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(updated),
            });

            if (res.ok) {
                const saved = await res.json();
                localStorage.setItem("user", JSON.stringify(saved));
                setUser(saved);
                showToast("Profil mis à jour !");
                setForm({ ...form, password: "" });
            } else {
                showToast("Erreur lors de la mise à jour.");
            }
        } catch {
            showToast("Erreur réseau");
        }
    };

    // Affichage d’un toast temporaire
    const showToast = (message) => {
        setToast(message);
        setTimeout(() => setToast(null), 4000);
    };

    // ================= RENDER =================
    return (
        <div className="flex min-h-screen bg-gradient-to-r from-yellow-400 to-black text-white font-poppins">
            {/* Barre latérale (navigation) */}
            <aside className="w-60 bg-black bg-opacity-90 p-8 flex flex-col">
                <h2 className="text-yellow-400 text-2xl font-semibold mb-10">Opérateur</h2>
                <nav className="flex flex-col space-y-4 text-lg">
                    <button onClick={() => setTab("file")} className={`text-left hover:text-yellow-400 ${tab === "file" ? "text-yellow-400 font-semibold" : ""}`}>
                        👥 Suivi des clients
                    </button>
                    <button onClick={() => setTab("profil")} className={`text-left hover:text-yellow-400 ${tab === "profil" ? "text-yellow-400 font-semibold" : ""}`}>
                        👤 Mon profil
                    </button>
                </nav>
            </aside>

            {/* Contenu principal */}
            <main className="flex-1 p-10 relative">
                {/* Notification Toast */}
                {toast && (
                    <div className="absolute top-5 left-1/2 transform -translate-x-1/2 bg-green-600 text-white px-6 py-3 rounded shadow-lg z-50">
                        {toast}
                    </div>
                )}

                {/* Menu utilisateur en haut à droite */}
                <div className="absolute top-5 right-5 cursor-pointer select-none" ref={submenuRef}>
                    <span className="bg-gray-900 bg-opacity-80 px-4 py-2 rounded text-yellow-400 font-semibold" onClick={() => setSubmenuOpen(!submenuOpen)}>
                        👤 Opérateur ▾
                    </span>
                    {submenuOpen && (
                        <div className="absolute right-0 mt-2 w-36 bg-gray-900 rounded shadow-lg overflow-hidden z-10">
                            <button className="w-full text-left px-4 py-2 text-sm hover:bg-yellow-400 hover:text-black" onClick={handleLogout}>
                                Déconnexion
                            </button>
                        </div>
                    )}
                </div>

                {/* Onglet : Suivi des clients */}
                {tab === "file" && (
                    <>
                        <h1 className="text-3xl text-yellow-300 mb-6">👥 Suivi des clients</h1>

                        {loading ? (
                            <p>Chargement...</p>
                        ) : user?.guichet ? (
                            <>
                                <p>Guichet : <strong>{user.guichet.nom}</strong></p>
                                <p>Nombre de tickets en attente : <strong>{ticketsEnAttente.length}</strong></p>

                                {/* Boutons d'action */}
                                <button onClick={appelerSuivant} disabled={ticketsEnAttente.length === 0 || callingTicket} className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold px-4 py-2 rounded">
                                    📣 Appeler le ticket suivant
                                </button>
                                <button onClick={loadUser} disabled={loading} className="ml-4 bg-gray-700 hover:bg-gray-600 text-white font-semibold px-4 py-2 rounded">
                                    🔄 Actualiser
                                </button>

                                {/* Dernier ticket appelé */}
                                {dernierAppel && (
                                    <div className="bg-gray-800 p-4 mt-6 rounded">
                                        <h2 className="text-xl text-yellow-400 mb-2">Ticket appelé :</h2>
                                        <p><strong>Numéro :</strong> {dernierAppel.numero}</p>
                                        <p><strong>Date :</strong> {new Date(dernierAppel.dateCreation).toLocaleString()}</p>
                                        <p><strong>Nom client :</strong> {dernierAppel.user?.nom || "Inconnu"}</p>
                                        <p><strong>Email :</strong> {dernierAppel.user?.email || "Non fourni"}</p>
                                    </div>
                                )}

                                {/* Liste des tickets restants */}
                                <ul className="mt-6 space-y-2 max-h-[400px] overflow-y-auto">
                                    {ticketsEnAttente.map((t) => (
                                        <li key={t.id} className="bg-gray-800 p-3 rounded">
                                            🎫 Ticket <strong>{t.numero}</strong> — {new Date(t.dateCreation).toLocaleString()}
                                        </li>
                                    ))}
                                </ul>
                            </>
                        ) : (
                            <p className="text-red-500">Aucun guichet assigné à cet opérateur.</p>
                        )}
                    </>
                )}

                {/* Onglet : Mon profil */}
                {tab === "profil" && (
                    <>
                        <h1 className="text-3xl text-yellow-300 mb-6">👤 Mon Profil</h1>
                        <form onSubmit={handleUpdateProfile} className="bg-gray-900 p-6 rounded w-full max-w-xl">
                            <div className="mb-4">
                                <label className="block mb-1 text-yellow-400">Nom</label>
                                <input type="text" name="nom" value={form.nom} onChange={handleChange} className="w-full p-2 rounded bg-gray-700 text-white" />
                            </div>
                            <div className="mb-4">
                                <label className="block mb-1 text-yellow-400">Email</label>
                                <input type="email" name="email" value={form.email} onChange={handleChange} className="w-full p-2 rounded bg-gray-700 text-white" />
                            </div>
                            <div className="mb-4">
                                <label className="block mb-1 text-yellow-400">Téléphone</label>
                                <input type="text" name="telephone" value={form.telephone} onChange={handleChange} className="w-full p-2 rounded bg-gray-700 text-white" />
                            </div>
                            <div className="mb-6">
                                <label className="block mb-1 text-yellow-400">Nouveau mot de passe (optionnel)</label>
                                <input type="password" name="password" value={form.password} onChange={handleChange} className="w-full p-2 rounded bg-gray-700 text-white" />
                            </div>
                            <button type="submit" className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold px-4 py-2 rounded">
                                Enregistrer les modifications
                            </button>
                        </form>
                    </>
                )}
            </main>
        </div>
    );
}
