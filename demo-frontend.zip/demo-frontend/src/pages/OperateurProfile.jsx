import React, { useState, useEffect } from "react";

export default function OperateurProfile() {
    // État pour stocker l'utilisateur courant
    const [user, setUser] = useState(null);

    // État pour gérer le formulaire de mise à jour du profil
    const [form, setForm] = useState({
        nom: "",
        email: "",
        telephone: "",
        password: "" // champ vide au départ, mis à jour uniquement si rempli
    });

    // Chargement de l'utilisateur depuis le localStorage au montage du composant
    useEffect(() => {
        const savedUser = JSON.parse(localStorage.getItem("user"));
        if (savedUser) {
            setUser(savedUser);
            setForm({
                nom: savedUser.nom || "",
                email: savedUser.email || "",
                telephone: savedUser.telephone || "",
                password: ""
            });
        }
    }, []);

    // Mise à jour du formulaire à chaque saisie utilisateur
    const handleChange = (e) => {
        const { name, value } = e.target;
        setForm({ ...form, [name]: value });
    };

    // Soumission du formulaire de mise à jour
    const handleSubmit = async (e) => {
        e.preventDefault();

        // Construction de l'objet utilisateur à mettre à jour
        const updatedUser = {
            ...user,
            nom: form.nom,
            email: form.email,
            telephone: form.telephone,
        };

        // Ajouter le mot de passe uniquement s'il est renseigné
        if (form.password) {
            updatedUser.password = form.password;
        }

        try {
            // Requête PUT pour mettre à jour l'utilisateur
            const response = await fetch(`/api/users/${user.id}`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(updatedUser)
            });

            // Traitement de la réponse
            if (response.ok) {
                const updated = await response.json();
                localStorage.setItem("user", JSON.stringify(updated)); // Mise à jour du localStorage
                alert("Profil mis à jour avec succès !");
            } else {
                alert("Erreur lors de la mise à jour.");
            }
        } catch (err) {
            console.error(err);
            alert("Erreur serveur.");
        }
    };

    // ================= RENDER =================
    return (
        <div className="p-10 font-poppins min-h-screen bg-gradient-to-r from-yellow-400 to-black text-white">
            <h1 className="text-3xl text-yellow-300 mb-6">👤 Mon Profil</h1>

            {/* Formulaire de mise à jour du profil */}
            <form onSubmit={handleSubmit} className="bg-gray-900 p-6 rounded w-full max-w-xl">
                {/* Champ Nom */}
                <div className="mb-4">
                    <label className="block mb-1 text-yellow-400">Nom</label>
                    <input
                        type="text"
                        name="nom"
                        value={form.nom}
                        onChange={handleChange}
                        className="w-full p-2 rounded bg-gray-700 text-white"
                    />
                </div>

                {/* Champ Email */}
                <div className="mb-4">
                    <label className="block mb-1 text-yellow-400">Email</label>
                    <input
                        type="email"
                        name="email"
                        value={form.email}
                        onChange={handleChange}
                        className="w-full p-2 rounded bg-gray-700 text-white"
                    />
                </div>

                {/* Champ Téléphone */}
                <div className="mb-4">
                    <label className="block mb-1 text-yellow-400">Téléphone</label>
                    <input
                        type="text"
                        name="telephone"
                        value={form.telephone}
                        onChange={handleChange}
                        className="w-full p-2 rounded bg-gray-700 text-white"
                    />
                </div>

                {/* Champ Mot de passe (optionnel) */}
                <div className="mb-6">
                    <label className="block mb-1 text-yellow-400">Nouveau mot de passe (optionnel)</label>
                    <input
                        type="password"
                        name="password"
                        value={form.password}
                        onChange={handleChange}
                        className="w-full p-2 rounded bg-gray-700 text-white"
                    />
                </div>

                {/* Bouton de soumission */}
                <button
                    type="submit"
                    className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold px-4 py-2 rounded"
                >
                    Enregistrer les modifications
                </button>
            </form>
        </div>
    );
}
