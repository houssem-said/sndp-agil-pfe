import React, { useEffect, useState } from "react";

export default function ClientDashboard() {
    const [user, setUser] = useState(null);
    const [agences, setAgences] = useState([]);
    const [services, setServices] = useState([]);
    const [selectedAgence, setSelectedAgence] = useState("");
    const [selectedService, setSelectedService] = useState("");
    const [rdvDate, setRdvDate] = useState("");
    const [rdvHeure, setRdvHeure] = useState("");
    const [rendezVousList, setRendezVousList] = useState([]);
    const [tickets, setTickets] = useState([]);
    const [fileAttente, setFileAttente] = useState({
        position: null,
        enTraitement: null,
        tempsEstime: null,
    });
    const [editMode, setEditMode] = useState(false);
    const [formData, setFormData] = useState({
        nom: "",
        email: "",
        telephone: "",
        password: "",
        confirmPassword: "",
    });
    const [selectedAgenceTicket, setSelectedAgenceTicket] = useState("");
    const [ticketDate, setTicketDate] = useState("");
    const [ticketHeure, setTicketHeure] = useState("");
    const [dateError, setDateError] = useState(null);
    const [ticketDateError, setTicketDateError] = useState(null);
    const [toast, setToast] = useState(null);

    // Trouver le nom d'une agence par son id
    const getNomAgenceById = (id) => {
        const ag = agences.find((a) => a.id === id);
        return ag ? ag.nom : "N/A";
    };

    // Trouver le nom d'un service par son id
    const getNomServiceById = (id) => {
        const s = services.find((srv) => srv.id === id);
        return s ? s.nom : "N/A";
    };

    // Toast display helper
    const showToast = (message) => {
        setToast(message);
        setTimeout(() => setToast(null), 3000);
    };

    // Fetch agences list
    const fetchAgences = () => {
        fetch("/api/agences")
            .then((res) => (res.ok ? res.json() : []))
            .then((data) => setAgences(Array.isArray(data) ? data : []))
            .catch(() => setAgences([]));
    };

    // Fetch services list
    const fetchServices = () => {
        fetch("/api/services")
            .then((res) => (res.ok ? res.json() : []))
            .then((data) => setServices(Array.isArray(data) ? data : []))
            .catch(() => setServices([]));
    };

    // Fetch user rendez-vous, tickets, file d’attente
    const fetchUserData = (userId) => {
        if (!userId) return;

        fetch(`/api/rendezvous/user/${userId}`)
            .then((res) => (res.ok ? res.json() : []))
            .then((data) => setRendezVousList(Array.isArray(data) ? data : []))
            .catch(() => setRendezVousList([]));

        fetch(`/api/tickets/user/${userId}`)
            .then((res) => (res.ok ? res.json() : []))
            .then((data) => setTickets(Array.isArray(data) ? data : []))
            .catch(() => setTickets([]));

        fetch(`/api/file-attente/user/${userId}`)
            .then((res) => (res.ok ? res.json() : null))
            .then((data) => {
                if (data && typeof data === "object") setFileAttente(data);
                else setFileAttente({ position: null, enTraitement: null, tempsEstime: null });
            })
            .catch(() => setFileAttente({ position: null, enTraitement: null, tempsEstime: null }));
    };

    // Load user and initial data on mount
    useEffect(() => {
        const storedUser = JSON.parse(localStorage.getItem("user"));
        if (storedUser) {
            setUser(storedUser);
            setFormData({
                nom: storedUser.nom || "",
                email: storedUser.email || "",
                telephone: storedUser.telephone || "",
                password: "",
                confirmPassword: "",
            });

            fetchUserData(storedUser.id);

            const intervalId = setInterval(() => {
                fetchUserData(storedUser.id);
                showToast("Données mises à jour automatiquement");
            }, 5 * 60 * 1000);

            fetchAgences();
            fetchServices();

            return () => clearInterval(intervalId);
        } else {
            fetchAgences();
            fetchServices();
        }
    }, []);

    // Validation for RDV date: no past dates, no weekends
    const handleDateChange = (e) => {
        const selected = e.target.value;
        setRdvDate(selected);
        setDateError(null);

        if (!selected) return;

        const selectedDate = new Date(selected + "T00:00:00");
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        if (selectedDate < today) {
            setDateError("La date ne peut pas être antérieure à aujourd'hui.");
            setRdvDate("");
            return;
        }

        const day = selectedDate.getDay();
        if (day === 0 || day === 6) {
            setDateError("Les rendez-vous ne peuvent pas être pris les samedis et dimanches.");
            setRdvDate("");
        }
    };

    // Validation for ticket date: same rules
    const handleTicketDateChange = (e) => {
        const selected = e.target.value;
        setTicketDate(selected);
        setTicketDateError(null);

        if (!selected) return;

        const selectedDate = new Date(selected + "T00:00:00");
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        if (selectedDate < today) {
            setTicketDateError("La date ne peut pas être antérieure à aujourd'hui.");
            setTicketDate("");
            return;
        }

        const day = selectedDate.getDay();
        if (day === 0 || day === 6) {
            setTicketDateError("Les tickets ne peuvent pas être pris les samedis et dimanches.");
            setTicketDate("");
        }
    };

    // Generate 15min slots 8:00-11:45 and 13:30-16:45
    const generateCreneaux = () => {
        const creneaux = [];
        let current = new Date();
        current.setHours(8, 0, 0, 0);
        const morningEnd = new Date();
        morningEnd.setHours(11, 45, 0, 0);

        while (current <= morningEnd) {
            creneaux.push(
                `${current.getHours().toString().padStart(2, "0")}:${current
                    .getMinutes()
                    .toString()
                    .padStart(2, "0")}`
            );
            current.setMinutes(current.getMinutes() + 15);
        }

        current = new Date();
        current.setHours(13, 30, 0, 0);
        const afternoonEnd = new Date();
        afternoonEnd.setHours(16, 45, 0, 0);

        while (current <= afternoonEnd) {
            creneaux.push(
                `${current.getHours().toString().padStart(2, "0")}:${current
                    .getMinutes()
                    .toString()
                    .padStart(2, "0")}`
            );
            current.setMinutes(current.getMinutes() + 15);
        }

        return creneaux;
    };

    // Taken hours on selected agency and date
    const takenHeures = rendezVousList
        .filter((rdv) => rdv.agenceId === selectedAgence && rdv.date === rdvDate)
        .map((rdv) => rdv.heure);

    // Submit RDV
    const handleRdvSubmit = (e) => {
        e.preventDefault();
        if (!selectedAgence || !selectedService || !rdvDate || !rdvHeure) {
            alert("Merci de remplir tous les champs");
            return;
        }
        if (dateError) {
            alert(dateError);
            return;
        }
        if (takenHeures.includes(rdvHeure)) {
            alert("Ce créneau est déjà pris, veuillez en choisir un autre.");
            return;
        }

        const rdvData = {
            userId: user.id,
            agenceId: selectedAgence,
            serviceId: selectedService,
            date: rdvDate,
            heure: rdvHeure,
        };

        fetch("/api/rendezvous", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(rdvData),
        })
            .then((res) => {
                if (!res.ok) throw new Error("Erreur lors de la prise de rendez-vous");
                return res.json();
            })
            .then((newRdv) => {
                setRendezVousList((prev) => [...prev, newRdv]);
                showToast("Rendez-vous pris avec succès !");
                return fetch(`/api/tickets/user/${user.id}`);
            })
            .then((res) => (res.ok ? res.json() : []))
            .then((data) => setTickets(Array.isArray(data) ? data : []))
            .catch((err) => alert(err.message));
    };

    // Submit ticket sans RDV
    const handleTicketSubmit = (e) => {
        e.preventDefault();
        if (!selectedAgenceTicket || !ticketDate || !ticketHeure) {
            alert("Merci de remplir tous les champs");
            return;
        }
        if (ticketDateError) {
            alert(ticketDateError);
            return;
        }

        fetch(`/api/tickets/prise-sans-rdv?userId=${user.id}&agenceId=${selectedAgenceTicket}`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ date: ticketDate, heure: ticketHeure }),
        })
            .then((res) => {
                if (!res.ok) throw new Error("Erreur lors de la prise de ticket");
                return res.json();
            })
            .then((newTicket) => {
                setTickets((prev) => [...prev, newTicket]);
                showToast("Ticket pris avec succès !");
                return fetch(`/api/file-attente/user/${user.id}`);
            })
            .then((res) => (res.ok ? res.json() : null))
            .then((data) => setFileAttente(data || { position: null, enTraitement: null, tempsEstime: null }))
            .catch((err) => alert(err.message));
    };

    // Cancel ticket
    const handleAnnulerTicket = (ticketId) => {
        if (!window.confirm("Voulez-vous vraiment annuler ce ticket ?")) return;

        fetch(`/api/tickets/${ticketId}`, { method: "DELETE" })
            .then((res) => {
                if (!res.ok) throw new Error("Erreur lors de l'annulation du ticket");
                setTickets((prev) => prev.filter((t) => t.id !== ticketId));
                showToast("Ticket annulé");
                return fetch(`/api/file-attente/user/${user.id}`);
            })
            .then((res) => (res.ok ? res.json() : null))
            .then((data) => setFileAttente(data || { position: null, enTraitement: null, tempsEstime: null }))
            .catch((err) => alert(err.message));
    };

    // Cancel RDV
    const handleAnnulerRdv = (rdvId) => {
        if (!window.confirm("Voulez-vous vraiment annuler ce rendez-vous ?")) return;

        fetch(`/api/rendezvous/${rdvId}`, { method: "DELETE" })
            .then((res) => {
                if (!res.ok) throw new Error("Erreur lors de l'annulation du rendez-vous");
                setRendezVousList((prev) => prev.filter((rdv) => rdv.id !== rdvId));
                showToast("Rendez-vous annulé");
            })
            .catch((err) => alert(err.message));
    };

    // Form changes for user info edit
    const handleFormChange = (e) => {
        setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
    };

    // Toggle edit mode for client info
    const handleEditToggle = () => setEditMode(!editMode);

    // Save client info update
    const handleSaveClientInfo = () => {
        if (formData.password && formData.password !== formData.confirmPassword) {
            alert("Les mots de passe ne correspondent pas.");
            return;
        }

        const updatedData = {
            nom: formData.nom,
            email: formData.email,
            telephone: formData.telephone,
        };

        if (formData.password) {
            updatedData.password = formData.password;
        }

        fetch(`/api/users/${user.id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(updatedData),
        })
            .then((res) => {
                if (!res.ok) throw new Error("Erreur lors de la mise à jour");
                return res.json();
            })
            .then((updatedUser) => {
                delete updatedUser.password;
                setUser(updatedUser);
                localStorage.setItem("user", JSON.stringify(updatedUser));
                showToast("Informations mises à jour");
                setEditMode(false);
            })
            .catch((err) => alert(err.message));
    };

    // Logout user
    const handleLogout = () => {
        localStorage.removeItem("user");
        window.location.href = "/";
    };

    // Manual data refresh
    const handleManualUpdate = () => {
        if (user?.id) {
            fetchUserData(user.id);
            showToast("Données mises à jour manuellement");
        }
    };

    return (
        <div className="p-6 bg-gradient-to-r from-yellow-400 to-black text-white min-h-screen font-poppins">
            {toast && (
                <div className="fixed top-4 left-1/2 transform -translate-x-1/2 bg-yellow-400 text-black px-6 py-3 rounded shadow-lg z-50 select-none pointer-events-none">
                    {toast}
                </div>
            )}

            <div className="flex justify-between items-center mb-6">
                <h1 className="text-3xl font-bold">Espace Client</h1>
                <button onClick={handleLogout} className="bg-red-600 px-4 py-2 rounded hover:bg-red-700 transition">
                    Se déconnecter
                </button>
            </div>

            <div className="mb-4">
                <button
                    onClick={handleManualUpdate}
                    className="bg-yellow-400 text-black px-4 py-2 rounded hover:bg-yellow-500 transition"
                    type="button"
                >
                    🔄 Mettre à jour
                </button>
            </div>

            {/* MES INFOS */}
            <section className="bg-black bg-opacity-60 p-4 rounded mb-8" aria-label="Mes informations personnelles">
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-xl text-yellow-400">Mes informations</h2>
                    <button onClick={handleEditToggle} className="bg-yellow-400 text-black px-4 py-2 rounded transition" type="button">
                        {editMode ? "Annuler" : "Modifier"}
                    </button>
                </div>
                {editMode ? (
                    <form
                        onSubmit={(e) => {
                            e.preventDefault();
                            handleSaveClientInfo();
                        }}
                        className="space-y-2"
                    >
                        <input
                            name="nom"
                            value={formData.nom}
                            onChange={handleFormChange}
                            placeholder="Nom"
                            className="w-full p-2 text-black rounded"
                            required
                        />
                        <input
                            name="email"
                            value={formData.email}
                            onChange={handleFormChange}
                            placeholder="Email"
                            type="email"
                            className="w-full p-2 text-black rounded"
                            required
                        />
                        <input
                            name="telephone"
                            value={formData.telephone}
                            onChange={handleFormChange}
                            placeholder="Téléphone"
                            className="w-full p-2 text-black rounded"
                            required
                        />
                        <input
                            name="password"
                            value={formData.password}
                            onChange={handleFormChange}
                            placeholder="Nouveau mot de passe"
                            type="password"
                            className="w-full p-2 text-black rounded"
                        />
                        <input
                            name="confirmPassword"
                            value={formData.confirmPassword}
                            onChange={handleFormChange}
                            placeholder="Confirmer le mot de passe"
                            type="password"
                            className="w-full p-2 text-black rounded"
                        />
                        <button
                            type="submit"
                            className="bg-yellow-400 text-black px-4 py-2 rounded hover:bg-yellow-500 transition"
                        >
                            Enregistrer
                        </button>
                    </form>
                ) : (
                    <ul className="space-y-1 list-disc list-inside">
                        <li>
                            <strong>Nom :</strong> {user?.nom || "N/A"}
                        </li>
                        <li>
                            <strong>Email :</strong> {user?.email || "N/A"}
                        </li>
                        <li>
                            <strong>Téléphone :</strong> {user?.telephone || "N/A"}
                        </li>
                    </ul>
                )}
            </section>

            {/* PRENDRE RENDEZ-VOUS */}
            <section className="bg-black bg-opacity-60 p-4 rounded mb-8" aria-label="Prise de rendez-vous">
                <h2 className="text-xl mb-4 text-yellow-400">Prendre un rendez-vous</h2>
                <form onSubmit={handleRdvSubmit} className="space-y-4" noValidate>
                    <select
                        value={selectedAgence}
                        onChange={(e) => setSelectedAgence(e.target.value)}
                        className="w-full p-2 rounded text-black"
                        required
                        aria-required="true"
                    >
                        <option value="">Choisir une agence</option>
                        {agences.map((a) => (
                            <option key={a.id} value={a.id}>
                                {a.nom}
                            </option>
                        ))}
                    </select>

                    <select
                        value={selectedService}
                        onChange={(e) => setSelectedService(e.target.value)}
                        className="w-full p-2 rounded text-black"
                        required
                        aria-required="true"
                    >
                        <option value="">Choisir un service</option>
                        {services.map((s) => (
                            <option key={s.id} value={s.id}>
                                {s.nom}
                            </option>
                        ))}
                    </select>

                    <input
                        type="date"
                        value={rdvDate}
                        onChange={handleDateChange}
                        className="w-full p-2 rounded text-black"
                        required
                        aria-required="true"
                        min={new Date().toISOString().split("T")[0]}
                    />
                    {dateError && <p className="text-red-500">{dateError}</p>}

                    <select
                        value={rdvHeure}
                        onChange={(e) => setRdvHeure(e.target.value)}
                        className="w-full p-2 rounded text-black"
                        required
                        aria-required="true"
                        disabled={!rdvDate}
                    >
                        <option value="">Choisir une heure</option>
                        {generateCreneaux()
                            .filter((h) => !takenHeures.includes(h))
                            .map((h) => (
                                <option key={h} value={h}>
                                    {h}
                                </option>
                            ))}
                    </select>

                    <button
                        type="submit"
                        disabled={!selectedAgence || !selectedService || !rdvDate || !rdvHeure || dateError !== null}
                        className="bg-yellow-400 text-black px-4 py-2 rounded disabled:opacity-50 disabled:cursor-not-allowed hover:bg-yellow-500 transition"
                    >
                        Prendre rendez-vous
                    </button>
                </form>
            </section>

            {/* PRENDRE UN TICKET SANS RDV */}
            <section className="bg-black bg-opacity-60 p-4 rounded mb-8" aria-label="Prise de ticket sans rendez-vous">
                <h2 className="text-xl mb-4 text-yellow-400">Prendre un ticket sans rendez-vous</h2>
                <form onSubmit={handleTicketSubmit} className="space-y-4" noValidate>
                    <select
                        value={selectedAgenceTicket}
                        onChange={(e) => setSelectedAgenceTicket(e.target.value)}
                        className="w-full p-2 rounded text-black"
                        required
                        aria-required="true"
                    >
                        <option value="">Choisir une agence</option>
                        {agences.map((a) => (
                            <option key={a.id} value={a.id}>
                                {a.nom}
                            </option>
                        ))}
                    </select>

                    <input
                        type="date"
                        value={ticketDate}
                        onChange={handleTicketDateChange}
                        className="w-full p-2 rounded text-black"
                        required
                        aria-required="true"
                        min={new Date().toISOString().split("T")[0]}
                    />
                    {ticketDateError && <p className="text-red-500">{ticketDateError}</p>}

                    <select
                        value={ticketHeure}
                        onChange={(e) => setTicketHeure(e.target.value)}
                        className="w-full p-2 rounded text-black"
                        required
                        aria-required="true"
                        disabled={!ticketDate}
                    >
                        <option value="">Choisir une heure</option>
                        {generateCreneaux().map((h) => (
                            <option key={h} value={h}>
                                {h}
                            </option>
                        ))}
                    </select>

                    <button
                        type="submit"
                        disabled={!selectedAgenceTicket || !ticketDate || !ticketHeure || ticketDateError !== null}
                        className="bg-yellow-400 text-black px-4 py-2 rounded disabled:opacity-50 disabled:cursor-not-allowed hover:bg-yellow-500 transition"
                    >
                        Prendre un ticket
                    </button>
                </form>
            </section>

            {/* AFFICHAGE FILE D'ATTENTE */}
            <section
                className="bg-black bg-opacity-60 p-4 rounded mb-8"
                aria-label="Suivi de la file d'attente"
            >
                <h2 className="text-xl mb-4 text-yellow-400">Ma position dans la file d'attente</h2>
                {fileAttente.position !== null ? (
                    <ul className="list-disc list-inside space-y-1">
                        {/* Affichage du nom du guichet affecté au ticket */}
                        <li>
                            <strong>Guichet affecté :</strong> {fileAttente.guichet ? fileAttente.guichet.nom : "N/A"}

                        </li>
                        <li>
                            <strong>Position actuelle :</strong> {fileAttente.position}
                        </li>
                        <li>
                            <strong>Ticket en cours de traitement :</strong>{" "}
                            {fileAttente.enTraitement && fileAttente.enTraitement.trim() !== ""
                                ? fileAttente.enTraitement
                                : "Aucun"}
                        </li>
                        <li>
                            <strong>Temps estimé restant :</strong>{" "}
                            {fileAttente.tempsEstime !== null && fileAttente.tempsEstime !== undefined
                                ? `${fileAttente.tempsEstime} minutes`
                                : "Indisponible"}
                        </li>
                    </ul>
                ) : (
                    <p>Vous n’avez pas de ticket en attente actuellement.</p>
                )}
            </section>

            {/* LISTE DES TICKETS */}
            <section
                className="bg-black bg-opacity-60 p-4 rounded mb-8"
                aria-label="Liste des tickets"
            >
                <h2 className="text-xl mb-4 text-yellow-400">Mes tickets</h2>
                {tickets.length === 0 ? (
                    <p>Aucun ticket trouvé.</p>
                ) : (
                    <table className="w-full text-left border-collapse border border-yellow-400">
                        <thead>
                        <tr className="border border-yellow-400 bg-yellow-400 text-black">
                            <th className="border border-yellow-400 p-2">ID</th>
                            <th className="border border-yellow-400 p-2">Agence</th>
                            <th className="border border-yellow-400 p-2">Date</th>
                            <th className="border border-yellow-400 p-2">Heure</th>
                            <th className="border border-yellow-400 p-2">Statut</th>
                            <th className="border border-yellow-400 p-2">Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        {tickets.map((ticket) => {
                            // Parser la date de manière sécurisée
                            const ticketDateObj = ticket.dateTicket ? new Date(ticket.dateTicket) : null;
                            const formattedDate = ticketDateObj ? ticketDateObj.toLocaleDateString("fr-FR") : "N/A";
                            const formattedHeure = ticketDateObj ? ticketDateObj.toLocaleTimeString("fr-FR", {hour:'2-digit', minute:'2-digit'}) : "-";
                            // Vérifier que la date est valide avant formatage
                            const isValidDate = !isNaN(ticketDateObj.getTime());


                            return (
                                <tr key={ticket.id} className="border border-yellow-400">
                                    <td className="border border-yellow-400 p-2">{ticket.id}</td>
                                    <td className="border border-yellow-400 p-2">{ticket.agence ? ticket.agence.nom : "N/A"}</td>
                                    <td className="border border-yellow-400 p-2">{formattedDate}</td>
                                    <td className="border border-yellow-400 p-2">{formattedHeure}</td>
                                    <td className="border border-yellow-400 p-2">{ticket.statut || "En attente"}</td>
                                    <td className="border border-yellow-400 p-2">
                                        <button
                                            onClick={() => handleAnnulerTicket(ticket.id)}
                                            className="bg-red-600 px-2 py-1 rounded hover:bg-red-700 transition"
                                        >
                                            Annuler
                                        </button>
                                    </td>
                                </tr>
                            );
                        })}
                        </tbody>
                    </table>
                )}
            </section>

            {/* LISTE DES RENDEZ-VOUS */}
            <section
                className="bg-black bg-opacity-60 p-4 rounded mb-8"
                aria-label="Liste des rendez-vous"
            >
                <h2 className="text-xl mb-4 text-yellow-400">Mes rendez-vous</h2>
                {rendezVousList.length === 0 ? (
                    <p>Aucun rendez-vous trouvé.</p>
                ) : (
                    <table className="w-full text-left border-collapse border border-yellow-400">
                        <thead>
                        <tr className="border border-yellow-400 bg-yellow-400 text-black">
                            <th className="border border-yellow-400 p-2">ID</th>
                            <th className="border border-yellow-400 p-2">Agence</th>
                            <th className="border border-yellow-400 p-2">Service</th>
                            <th className="border border-yellow-400 p-2">Date</th>
                            <th className="border border-yellow-400 p-2">Heure</th>
                            <th className="border border-yellow-400 p-2">Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        {rendezVousList.map((rdv) => {
                            const rdvDateObj = new Date(rdv.date + "T" + (rdv.heure || "00:00"));
                            const isValidDate = !isNaN(rdvDateObj.getTime());
                            const formattedDate = isValidDate
                                ? rdvDateObj.toLocaleDateString("fr-FR", {
                                    year: "numeric",
                                    month: "2-digit",
                                    day: "2-digit",
                                })
                                : "N/A";
                            const formattedHeure = rdv.heure && rdv.heure.trim() !== "" ? rdv.heure : "-";

                            return (
                                <tr key={rdv.id} className="border border-yellow-400">
                                    <td className="border border-yellow-400 p-2">{rdv.id}</td>
                                    <td className="border border-yellow-400 p-2">{rdv.agence ? rdv.agence.nom : "N/A"}</td>
                                    <td className="border border-yellow-400 p-2">{rdv.service ? rdv.service.nom : "N/A"}</td>
                                    <td className="border border-yellow-400 p-2">{formattedDate}</td>
                                    <td className="border border-yellow-400 p-2">{formattedHeure}</td>
                                    <td className="border border-yellow-400 p-2">
                                        <button
                                            onClick={() => handleAnnulerRdv(rdv.id)}
                                            className="bg-red-600 px-2 py-1 rounded hover:bg-red-700 transition"
                                        >
                                            Annuler
                                        </button>
                                    </td>
                                </tr>
                            );
                        })}
                        </tbody>
                    </table>
                )}
            </section>
        </div>
    );
}
