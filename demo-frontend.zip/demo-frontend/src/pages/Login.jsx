import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

export default function Login() {
    const [email, setEmail] = useState("");
    const [motDePasse, setMotDePasse] = useState("");
    const [error, setError] = useState("");
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError("");
        try {
            const response = await fetch("/api/auth/login", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ email, motDePasse }),
            });
            if (!response.ok) {
                const err = await response.json();
                setError(err.error || "Erreur de connexion");
                return;
            }
            const data = await response.json();
            localStorage.setItem("user", JSON.stringify(data));
            if (data.role === "USER") navigate("/client-dashboard");
            else if (data.role === "OPERATEUR") navigate("/operateur-dashboard");
            else if (data.role === "ADMIN") navigate("/admin-dashboard");
            else navigate("/");
        } catch {
            setError("Impossible de contacter le serveur");
        }
    };

    return (
        <div
            className="min-h-screen h-screen bg-black bg-cover bg-center flex items-center justify-center font-poppins"
            style={{
                backgroundImage: "url('/images/acc.webp')",
                backgroundRepeat: "no-repeat",
                backgroundSize: "cover",
            }}
        >
            <div className="bg-gray-900 bg-opacity-90 p-10 rounded-xl shadow-lg max-w-md w-full text-center text-white">
                <img
                    src="/images/logo.gif"
                    alt="Logo Agile"
                    className="mx-auto w-24 mb-6"
                />
                <h2 className="text-yellow-400 text-3xl font-bold mb-8">Connexion</h2>
                <form onSubmit={handleSubmit}>
                    <label htmlFor="email" className="block text-left mb-1 font-medium">
                        Adresse e-mail
                    </label>
                    <input
                        type="email"
                        id="email"
                        name="email"
                        placeholder="exemple@domaine.com"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full p-3 rounded-md bg-gray-800 text-white mb-6 focus:outline-yellow-400"
                    />
                    <label
                        htmlFor="password"
                        className="block text-left mb-1 font-medium"
                    >
                        Mot de passe
                    </label>
                    <input
                        type="password"
                        id="password"
                        name="password"
                        placeholder="********"
                        required
                        value={motDePasse}
                        onChange={(e) => setMotDePasse(e.target.value)}
                        className="w-full p-3 rounded-md bg-gray-800 text-white mb-6 focus:outline-yellow-400"
                    />
                    {error && <p className="text-red-500 mb-4">{error}</p>}
                    <button
                        type="submit"
                        className="w-full py-3 bg-yellow-400 text-black font-bold rounded-md hover:bg-yellow-500 transition"
                    >
                        Se connecter
                    </button>
                </form>
                <div className="mt-6 text-yellow-400 space-y-2">
                    <p>
                        Pas encore de compte ?{" "}
                        <Link to="/register" className="underline hover:text-yellow-300">
                            S'inscrire
                        </Link>
                    </p>
                    <p>
                        <Link to="/" className="underline hover:text-yellow-300">
                            ← Retour à l'accueil
                        </Link>
                    </p>
                </div>
            </div>
        </div>
    );
}
