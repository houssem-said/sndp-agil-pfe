import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";

export default function AdminProfile() {
    const navigate = useNavigate();

    // État pour gérer l'ouverture/fermeture du menu utilisateur déroulant
    const [submenuOpen, setSubmenuOpen] = useState(false);
    const submenuRef = useRef(null); // Référence pour détecter clic hors menu

    // Stockage de l'utilisateur connecté
    const [user, setUser] = useState(null);

    // Mode édition : false = affichage simple, true = formulaire éditable
    const [editMode, setEditMode] = useState(false);

    // Données du formulaire d'édition profil
    const [formData, setFormData] = useState({
        nomComplet: "",          // Nom complet (nom au backend)
        email: "",
        telephone: "",
        motDePasse: "",
        confirmerMotDePasse: "",
    });

    // Messages d'erreur et succès à afficher à l'utilisateur
    const [error, setError] = useState(null);
    const [message, setMessage] = useState(null);

    // Au chargement du composant, récupérer les infos utilisateur depuis localStorage
    useEffect(() => {
        const storedUser = JSON.parse(localStorage.getItem("user"));
        if (storedUser) {
            setUser(storedUser);
            setFormData({
                nomComplet: storedUser.nomComplet || storedUser.nom || "", // fallback nom
                email: storedUser.email || "",
                telephone: storedUser.telephone || "",
                motDePasse: "",
                confirmerMotDePasse: "",
            });
        }
    }, []);

    // Fermer le menu utilisateur si clic hors de celui-ci
    useEffect(() => {
        function handleClickOutside(event) {
            if (submenuRef.current && !submenuRef.current.contains(event.target)) {
                setSubmenuOpen(false);
            }
        }
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    // Validation simple des champs du formulaire avant envoi
    function validate() {
        if (!formData.nomComplet.trim()) return "Le nom complet est requis";
        if (!formData.email.trim()) return "L'email est requis";
        if (!formData.telephone.trim()) return "Le téléphone est requis";
        if (formData.motDePasse !== formData.confirmerMotDePasse)
            return "Les mots de passe ne correspondent pas";
        return null;
    }

    // Gestion des changements dans les inputs du formulaire (réactive)
    const handleFormChange = (e) => {
        setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
    };

    // Envoi du formulaire de mise à jour profil vers backend
    const handleSave = async () => {
        setError(null);
        setMessage(null);

        // Validation locale avant appel API
        const err = validate();
        if (err) {
            setError(err);
            return;
        }

        // Préparer les données à envoyer (si mot de passe renseigné, on l'envoie)
        const updatedData = {
            id: user.id,
            nomComplet: formData.nomComplet,
            email: formData.email,
            telephone: formData.telephone,
        };
        if (formData.motDePasse) {
            updatedData.motDePasse = formData.motDePasse;
        }

        try {
            // Requête PUT vers /api/admin/profile pour mettre à jour profil
            const res = await fetch(`/api/admin/profile`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(updatedData),
            });

            if (!res.ok) {
                const data = await res.json();
                throw new Error(data.message || "Erreur lors de la mise à jour");
            }

            // Mise à jour du state user local et localStorage
            const updatedUser = { ...user, ...updatedData };
            setUser(updatedUser);
            localStorage.setItem("user", JSON.stringify(updatedUser));

            setMessage("Profil mis à jour avec succès !");
            setEditMode(false);

            // Réinitialisation champs mot de passe du formulaire
            setFormData((f) => ({ ...f, motDePasse: "", confirmerMotDePasse: "" }));
        } catch (e) {
            setError(e.message);
        }
    };

    // Déconnexion : nettoyage localStorage + redirection login
    const handleLogout = () => {
        localStorage.removeItem("user");
        navigate("/login");
    };

    // Retour au tableau de bord admin
    const handleBack = () => {
        navigate("/admin-dashboard");
    };

    return (
        <div className="flex min-h-screen bg-gradient-to-r from-yellow-400 to-black text-white font-poppins relative">
            {/* Sidebar latérale */}
            <aside className="w-60 bg-black bg-opacity-90 p-8 flex flex-col space-y-4">
                <h2 className="text-yellow-400 text-2xl font-bold">Admin</h2>
                <button
                    className="text-left text-yellow-400 font-semibold"
                    onClick={handleBack}
                >
                    📊 Tableau de bord
                </button>
                <button
                    className="text-left hover:text-yellow-300"
                    onClick={() => navigate("/admin-users")}
                >
                    👥 Gérer les comptes
                </button>
                <button
                    className="text-left hover:text-yellow-300"
                    onClick={() => navigate("/admin-profile")}
                >
                    🔐 Mon profil
                </button>
            </aside>

            {/* Menu utilisateur déroulant en haut à droite */}
            <div
                className="absolute top-5 right-5 cursor-pointer select-none"
                ref={submenuRef}
            >
                <span
                    className="bg-gray-900 bg-opacity-80 px-4 py-2 rounded text-yellow-400 font-semibold"
                    onClick={() => setSubmenuOpen(!submenuOpen)}
                >
                    👤 Admin ▾
                </span>
                {submenuOpen && (
                    <div className="absolute right-0 mt-2 w-36 bg-gray-900 rounded shadow-lg overflow-hidden z-50">
                        <button
                            className="w-full text-left px-4 py-2 text-sm hover:bg-yellow-400 hover:text-black"
                            onClick={handleLogout}
                        >
                            Déconnexion
                        </button>
                    </div>
                )}
            </div>

            {/* Contenu principal centré */}
            <main className="flex-1 p-8 flex items-center justify-center">
                <div className="bg-black bg-opacity-80 p-8 rounded-lg max-w-md w-full text-white">
                    <h2 className="text-yellow-400 text-2xl font-semibold mb-6">
                        Modifier profil Admin
                    </h2>

                    {/* Formulaire en mode édition */}
                    {editMode ? (
                        <form
                            onSubmit={(e) => {
                                e.preventDefault();
                                handleSave();
                            }}
                            className="space-y-5"
                        >
                            {/* Nom complet */}
                            <div>
                                <label
                                    htmlFor="nomComplet"
                                    className="block mb-1 font-medium"
                                >
                                    Nom complet
                                </label>
                                <input
                                    type="text"
                                    id="nomComplet"
                                    name="nomComplet"
                                    value={formData.nomComplet}
                                    onChange={handleFormChange}
                                    className="w-full rounded px-3 py-2 bg-gray-800 text-white focus:outline-yellow-400"
                                    required
                                />
                            </div>

                            {/* Email */}
                            <div>
                                <label htmlFor="email" className="block mb-1 font-medium">
                                    Email
                                </label>
                                <input
                                    type="email"
                                    id="email"
                                    name="email"
                                    value={formData.email}
                                    onChange={handleFormChange}
                                    className="w-full rounded px-3 py-2 bg-gray-800 text-white focus:outline-yellow-400"
                                    required
                                />
                            </div>

                            {/* Téléphone */}
                            <div>
                                <label
                                    htmlFor="telephone"
                                    className="block mb-1 font-medium"
                                >
                                    Téléphone
                                </label>
                                <input
                                    type="tel"
                                    id="telephone"
                                    name="telephone"
                                    value={formData.telephone}
                                    onChange={handleFormChange}
                                    className="w-full rounded px-3 py-2 bg-gray-800 text-white focus:outline-yellow-400"
                                    required
                                />
                            </div>

                            {/* Mot de passe (optionnel) */}
                            <div>
                                <label
                                    htmlFor="motDePasse"
                                    className="block mb-1 font-medium"
                                >
                                    Mot de passe
                                </label>
                                <input
                                    type="password"
                                    id="motDePasse"
                                    name="motDePasse"
                                    value={formData.motDePasse}
                                    onChange={handleFormChange}
                                    className="w-full rounded px-3 py-2 bg-gray-800 text-white focus:outline-yellow-400"
                                    placeholder="Laisser vide pour ne pas modifier"
                                />
                            </div>

                            {/* Confirmation mot de passe */}
                            <div>
                                <label
                                    htmlFor="confirmerMotDePasse"
                                    className="block mb-1 font-medium"
                                >
                                    Confirmer mot de passe
                                </label>
                                <input
                                    type="password"
                                    id="confirmerMotDePasse"
                                    name="confirmerMotDePasse"
                                    value={formData.confirmerMotDePasse}
                                    onChange={handleFormChange}
                                    className="w-full rounded px-3 py-2 bg-gray-800 text-white focus:outline-yellow-400"
                                    placeholder="Laisser vide si pas de changement"
                                />
                            </div>

                            {/* Messages d'erreur ou de succès */}
                            {error && <p className="text-red-500">{error}</p>}
                            {message && <p className="text-green-500">{message}</p>}

                            {/* Boutons enregistrer / annuler */}
                            <div className="flex gap-4">
                                <button
                                    type="submit"
                                    className="bg-yellow-400 text-black font-bold py-3 rounded hover:bg-yellow-500 transition"
                                >
                                    Enregistrer
                                </button>
                                <button
                                    type="button"
                                    className="underline"
                                    onClick={() => {
                                        // Annuler édition : reset form, erreur, message
                                        setEditMode(false);
                                        setError(null);
                                        setMessage(null);
                                        setFormData({
                                            nomComplet: user?.nomComplet || user?.nom || "",
                                            email: user?.email || "",
                                            telephone: user?.telephone || "",
                                            motDePasse: "",
                                            confirmerMotDePasse: "",
                                        });
                                    }}
                                >
                                    Annuler
                                </button>
                            </div>
                        </form>
                    ) : (
                        // Affichage profil en lecture seule
                        <div>
                            <p>
                                <strong>Nom complet :</strong> {user?.nomComplet || user?.nom}
                            </p>
                            <p>
                                <strong>Email :</strong> {user?.email}
                            </p>
                            <p>
                                <strong>Téléphone :</strong> {user?.telephone || "-"}
                            </p>
                            <button
                                className="mt-4 bg-yellow-400 text-black px-4 py-2 rounded"
                                onClick={() => setEditMode(true)}
                            >
                                Modifier mes informations
                            </button>
                        </div>
                    )}
                </div>
            </main>
        </div>
    );
}
