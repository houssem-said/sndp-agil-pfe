import React, { useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { FaFacebook, FaInstagram } from "react-icons/fa";

export default function Home() {
    const navigate = useNavigate();

    useEffect(() => {
        fetch("/")
            .then((res) => {
                if (!res.ok) throw new Error(`Erreur HTTP: ${res.status}`);
                return res.text();
            })
            .then((data) => console.log("Backend message:", data))
            .catch((err) => console.error("Erreur connexion backend :", err));
    }, []);

    useEffect(() => {
        function animateCircles() {
            document.querySelectorAll(".circle-fg").forEach((circle) => {
                const percent = parseInt(circle.getAttribute("data-percent"), 10);
                const circumference = 2 * Math.PI * circle.r.baseVal.value;
                const textContainer = circle.parentElement.parentElement.querySelector(".stat-value");

                const duration = 1500;
                const startTime = performance.now();

                function update(now) {
                    const elapsed = now - startTime;
                    const progress = Math.min(elapsed / duration, 1);
                    const value = Math.floor(progress * percent);
                    textContainer.textContent = `${value}%`;
                    const offset = circumference * (1 - progress * (percent / 100));
                    circle.style.strokeDashoffset = offset;

                    if (progress < 1) {
                        requestAnimationFrame(update);
                    } else {
                        textContainer.textContent = `${percent}%`;
                        circle.style.strokeDashoffset = circumference * (1 - percent / 100);
                    }
                }

                circle.style.strokeDasharray = circumference;
                circle.style.strokeDashoffset = circumference;

                requestAnimationFrame(update);
            });
        }

        let animated = false;

        function onScroll() {
            const stats = document.querySelector(".stats-container");
            if (!animated && stats && stats.getBoundingClientRect().top < window.innerHeight) {
                animated = true;
                animateCircles();
                window.removeEventListener("scroll", onScroll);
            }
        }

        window.addEventListener("scroll", onScroll);
        onScroll();

        const sections = document.querySelectorAll(".section-animate");
        const observer = new IntersectionObserver(
            (entries, obs) => {
                entries.forEach((entry) => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add("visible");
                        obs.unobserve(entry.target);
                    }
                });
            },
            { threshold: 0.1 }
        );
        sections.forEach((sec) => observer.observe(sec));

        return () => {
            window.removeEventListener("scroll", onScroll);
            sections.forEach((sec) => observer.unobserve(sec));
        };
    }, []);

    const services = [
        {
            img: "file.png",
            title: "Gestion des files d’attente",
            reverse: false,
            description:
                "Automatisez la gestion de vos files d’attente et offrez à vos visiteurs une qualité d’accueil optimale. Bornes personnalisables, intuitives, et faciles à prendre en main. Appel adapté à votre organisation et aux compétences de vos agents.",
        },
        {
            img: "GE.png",
            title: "Bornes interactives et accueil",
            reverse: true,
            description:
                "Offrez un accueil sur-mesure grâce à des bornes interactives : design élégant, grand écran, interface personnalisable et gestion multilingue.",
        },
        {
            img: "opti.jpg",
            title: "Tickets et files d’attente virtuelles",
            reverse: false,
            description:
                "Offrez mobilité et autonomie : tickets sur smartphone, scan QR code, suivi en temps réel, appel direct via téléphone.",
        },
        {
            img: "calendrier.png",
            title: "Prise de rendez-vous en ligne",
            reverse: true,
            description:
                "Optimisez vos ressources avec des créneaux configurables, modification et annulation en ligne. Intégration à votre site web assurée.",
        },
        {
            img: "dynamique.png",
            title: "Système d’affichage dynamique",
            reverse: false,
            description:
                "Affichage des tickets en cours, historique, temps d’attente, et diffusion de contenus multimédias personnalisés.",
        },
        {
            img: "",
            title: "Insight et reporting",
            reverse: true,
            description:
                "Analysez et pilotez vos services en temps réel via des tableaux de bord, stockage sécurisé et outils d’aide à la décision.",
        },
    ];

    const statsData = [
        { pct: 75, label: "Rendez-vous honorés" },
        { pct: 55, label: "Temps d’attente réduit" },
        { pct: 98, label: "Satisfaction client" },
    ];

    return (
        <div className="min-h-screen bg-gradient-to-r from-yellow-400 to-black text-white font-poppins">
            {/* Header */}
            <header className="flex justify-between items-center p-5 bg-black bg-opacity-80 z-20 relative">
                <h1 className="flex items-center text-2xl">
                    <img src="/images/logo.gif" alt="Logo Agil" className="h-10 mr-2" />
                    AgilQueue
                </h1>
                <nav className="flex items-center space-x-4">
                    <ul className="flex space-x-8">
                        <li>
                            <Link to="/" className="hover:text-yellow-400">Accueil</Link>
                        </li>
                        <li>
                            <a href="#propos" className="hover:text-yellow-400">À propos</a>
                        </li>
                        <li className="relative group cursor-pointer">
                            <span className="hover:text-yellow-400">Services</span>
                            <ul className="absolute top-full left-0 bg-black bg-opacity-95 border border-yellow-400 rounded-md hidden group-hover:flex flex-col">
                                {[
                                    "🕓 File d’attente",
                                    "🎫 Ticket virtuel",
                                    "📅 Prise de RDV",
                                    "📺 Affichage dynamique",
                                    "📊 Insight",
                                ].map((item) => (
                                    <li key={item}>
                                        <Link to="/login" className="block px-4 py-2 hover:bg-yellow-400 hover:text-black">
                                            {item}
                                        </Link>
                                    </li>
                                ))}
                            </ul>
                        </li>
                        <li>
                            <a href="#map" className="hover:text-yellow-400">Agences</a>
                        </li>
                        <li>
                            <a href="#contact" className="hover:text-yellow-400">Contact</a>
                        </li>
                    </ul>
                    <div className="flex space-x-4">
                        <Link to="/login">
                            <button className="btn bg-yellow-400 text-black font-bold px-6 py-2 rounded">Se connecter</button>
                        </Link>
                        <Link to="/register">
                            <button className="btn bg-yellow-400 text-black font-bold px-6 py-2 rounded">S'inscrire</button>
                        </Link>
                    </div>
                </nav>
            </header>

            {/* Hero */}
            <section className="heroo relative flex items-center justify-start p-16 overflow-hidden min-h-[70vh]">
                <div className="hero-text max-w-lg space-y-6 z-10 relative">
                    <h2 className="text-5xl font-semibold">
                        Optimisez votre temps dans nos agences
                    </h2>
                    <p className="text-lg">
                        Réservez vos créneaux, prenez un ticket à distance, et suivez la file d'attente en temps réel grâce à notre système de gestion connecté.
                    </p>
                    <button onClick={() => navigate("/login")} className="btn bg-yellow-400 text-black font-bold px-8 py-3 rounded">
                        Démarrer
                    </button>
                </div>
            </section>

            {/* À propos */}
            <section id="propos" className="section-animate py-16 bg-[#111]">
                <div className="flex flex-col md:flex-row items-center max-w-5xl mx-auto space-y-10 md:space-y-0 md:space-x-10">
                    <div className="space-y-4">
                        <h2 className="text-4xl font-semibold text-yellow-400">À propos de la Société AGIL</h2>
                        <p>
                            La Société nationale de distribution des pétroles (SNDP), connue sous la marque AGIL, est une entreprise publique tunisienne spécialisée dans la distribution de produits pétroliers.
                        </p>
                        <button className="btn bg-yellow-400 text-black font-bold px-6 py-2 rounded">À propos</button>
                    </div>
                    <img src="/images/acc.webp" alt="Station AGIL - photo" className="w-full md:w-1/2 rounded-xl" />
                </div>
            </section>

            {/* Services */}
            <section id="services" className="py-16 bg-[#111] space-y-16">
                <h2 className="text-3xl text-center font-semibold">Nos Solutions de Gestion</h2>
                {services.map(({ img, title, reverse, description }) => (
                    <div key={title} className={`flex flex-col ${reverse ? "md:flex-row-reverse" : "md:flex-row"} items-center max-w-5xl mx-auto space-y-6 md:space-y-0 md:space-x-10`}>
                        {img && (
                            <img src={`/images/${img}`} alt={title} className="w-full md:w-1/2 rounded-lg" />
                        )}
                        <div className="space-y-4 max-w-md">
                            <h3 className="text-2xl font-semibold text-yellow-400">{title}</h3>
                            <p>{description}</p>
                        </div>
                    </div>
                ))}
            </section>

            {/* Statistiques */}
            <section className="py-16 bg-[#111] section-animate">
                <h2 className="text-center text-3xl mb-8">Nos Résultats</h2>
                <div className="stats-container flex justify-center gap-12">
                    {statsData.map(({ pct, label }) => (
                        <div key={label} className="stat text-center">
                            <div className="circle-container relative w-32 h-32 mx-auto">
                                <svg width="120" height="120" className="-rotate-90">
                                    <circle cx="60" cy="60" r="60" stroke="#444" strokeWidth="10" fill="none" />
                                    <circle className="circle-fg" cx="60" cy="60" r="60" stroke="#ffc107" strokeWidth="10" fill="none" strokeDasharray="377" strokeDashoffset="377" data-percent={pct} />
                                </svg>
                                <div className="stat-value absolute inset-0 flex items-center justify-center text-yellow-400 text-xl font-bold">0%</div>
                            </div>
                            <p className="mt-4">{label}</p>
                        </div>
                    ))}
                </div>
            </section>

            {/* Map */}
            <section id="map" className="py-16 max-w-4xl mx-auto section-animate">
                <h3 className="text-2xl mb-6">Notre emplacement</h3>
                <iframe
                    src="https://www.google.com/maps?q=Cite+Olympique,+Tunis,+Tunisia&output=embed"
                    className="w-full h-96 border-0 rounded"
                    allowFullScreen
                    loading="lazy"
                    title="Carte Agil"
                />
            </section>

            {/* Footer */}
            <footer id="contact" className="bg-black bg-opacity-70 text-gray-300 py-8">
                <div className="max-w-5xl mx-auto flex flex-wrap justify-between space-y-6">
                    <div className="flex-1 min-w-[200px] space-y-2">
                        <h4 className="text-yellow-400">Contact</h4>
                        <p>BP 762 Ave Mohamed Ali Akid, Tunis 1003</p>
                        <p>Téléphone : 71 707 222</p>
                        <p><a href="mailto:boc@agil.com.tn" className="text-yellow-400">boc@agil.com.tn</a></p>
                    </div>
                    <div className="flex-1 min-w-[200px] space-y-2">
                        <h4 className="text-yellow-400">Réseaux sociaux & Site</h4>
                        <a href="https://www.facebook.com/agil.com.tn/?locale=fr_FR" target="_blank" rel="noreferrer" className="flex items-center space-x-2 text-yellow-400 hover:underline">
                            <FaFacebook size={24} /><span>Facebook</span>
                        </a>
                        <a href="https://www.instagram.com/agilenergytunisie/" target="_blank" rel="noreferrer" className="flex items-center space-x-2 text-yellow-400 hover:underline">
                            <FaInstagram size={24} /><span>Instagram</span>
                        </a>
                        <p><a href="https://agil.com.tn" target="_blank" rel="noreferrer" className="text-yellow-400 hover:underline">Site officiel : agil.com.tn</a></p>
                    </div>
                    <div className="flex-1 min-w-[200px] space-y-2">
                        <h4 className="text-yellow-400">Horaires & Prix</h4>
                        <p>lundi - vendredi, 08:00–17:00</p>
                        <p>week-end, fermé</p>
                        <p>Fourchette de prix · €€</p>
                    </div>
                </div>
                <div className="text-center text-sm text-gray-500 mt-6">
                    © 2025 AgilQueue - Tous droits réservés
                </div>
            </footer>

            {/* CSS animations */}
            <style>
                {`
                @keyframes slideBgMulti {
                    from { background-position: 0 0, 1000px 0, 2000px 0; }
                    to { background-position: -3000px 0, -2000px 0, -1000px 0; }
                }
                .heroo {
                    position: relative;
                    z-index: 1;
                }
                .heroo::before {
                    content: "";
                    position: absolute;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    background-image:
                        url("/images/agile2.jpg"),
                        url("/images/station-agil.jpg"),
                        url("/images/images.jpg");
                    background-repeat: repeat-x, repeat-x, repeat-x;
                    background-position: 0 0, 1000px 0, 2000px 0;
                    background-size: auto 100%, auto 100%, auto 100%;
                    animation: slideBgMulti 30s linear infinite;
                    opacity: 0.3;
                    z-index: 0;
                }
                .section-animate {
                    opacity: 0;
                    transform: translateY(30px);
                    transition: opacity 0.8s ease-out, transform 0.8s ease-out;
                    will-change: opacity, transform;
                }
                .section-animate.visible {
                    opacity: 1;
                    transform: translateY(0);
                }
                `}
            </style>
        </div>
    );
}
