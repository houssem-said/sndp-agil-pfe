import React, { useEffect, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";

/**
 * Composant Modal réutilisable pour afficher une fenêtre modale centrée avec un titre et un contenu.
 * @param {string} title - Le titre affiché en haut de la modal.
 * @param {function} onClose - Fonction appelée pour fermer la modal.
 * @param {ReactNode} children - Contenu JSX à afficher dans la modal.
 */
function Modal({ title, onClose, children }) {
    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50">
            <div className="bg-white rounded p-6 w-full max-w-md relative">
                <h3 className="text-xl font-bold mb-4">{title}</h3>
                <button
                    type="button"
                    onClick={onClose}
                    aria-label="Fermer"
                    className="absolute top-2 right-2 text-gray-500 hover:text-gray-800 font-bold text-xl"
                >
                    ×
                </button>
                <div>{children}</div>
            </div>
        </div>
    );
}

/**
 * Composant tableau affichant les utilisateurs filtrés par rôle et par recherche.
 * Utilise React.memo pour éviter des rerenders inutiles si les props ne changent pas.
 *
 * Props :
 * - title : titre de la section (ex : "Clients", "Admins")
 * - role : rôle des utilisateurs à afficher ("USER", "ADMIN", "OPERATEUR")
 * - search : chaîne de recherche pour filtrer les utilisateurs
 * - setSearch : fonction pour mettre à jour la recherche
 * - users : liste complète des utilisateurs
 * - selectedUser : utilisateur actuellement sélectionné (pour mise en surbrillance)
 * - onSelect : callback lors de la sélection d'un utilisateur
 */
const UserTable = React.memo(function UserTable({
                                                    title,
                                                    role,
                                                    search,
                                                    setSearch,
                                                    users,
                                                    selectedUser,
                                                    onSelect,
                                                }) {
    // Filtrer les utilisateurs par rôle et recherche (nom, email, téléphone)
    const filtered = users.filter(
        (u) =>
            u.role === role &&
            (`${u.nom ?? ""} ${u.email ?? ""} ${u.telephone ?? ""}`)
                .toLowerCase()
                .includes(search.toLowerCase())
    );

    return (
        <section className="mb-8">
            <div className="flex justify-between items-center mb-2">
                <h2 className="text-yellow-400 text-xl font-semibold">{title}</h2>
                <p className="text-sm italic text-gray-400">Total : {filtered.length}</p>
            </div>
            {/* Input pour filtrer par recherche */}
            <input
                type="text"
                placeholder="🔍 Rechercher..."
                className="mb-3 p-2 rounded w-full max-w-sm text-black"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                aria-label={`Rechercher dans ${title}`}
            />
            {/* Tableau affichant les utilisateurs filtrés */}
            <table className="w-full text-left border-collapse">
                <thead>
                <tr className="border-b border-yellow-400 text-yellow-400">
                    <th className="p-2">Nom</th>
                    <th className="p-2">Email</th>
                    <th className="p-2">Téléphone</th>
                </tr>
                </thead>
                <tbody>
                {filtered.length === 0 ? (
                    // Message si aucun utilisateur ne correspond aux filtres
                    <tr>
                        <td colSpan={3} className="p-2 text-gray-400 text-center">
                            Aucun résultat.
                        </td>
                    </tr>
                ) : (
                    // Liste des utilisateurs filtrés, chaque ligne est cliquable
                    filtered.map((user) => (
                        <tr
                            key={user.id}
                            className={`cursor-pointer border-b border-gray-600 hover:bg-yellow-400 hover:text-black ${
                                selectedUser?.id === user.id ? "bg-yellow-400 text-black" : ""
                            }`}
                            onClick={() => onSelect(user)}
                        >
                            <td className="p-2">{user.nom}</td>
                            <td className="p-2">{user.email}</td>
                            <td className="p-2">{user.telephone || "-"}</td>
                        </tr>
                    ))
                )}
                </tbody>
            </table>
        </section>
    );
});

/**
 * Composant principal de gestion des utilisateurs dans l’admin.
 * Permet d’afficher, rechercher, ajouter, modifier et supprimer des utilisateurs par rôle.
 */
function AdminUsers() {
    const navigate = useNavigate();

    // Stocke tous les utilisateurs récupérés depuis le backend
    const [allUsers, setAllUsers] = useState([]);
    // Utilisateur actuellement sélectionné dans la liste
    const [selectedUser, setSelectedUser] = useState(null);

    // États pour les champs de recherche dans chaque tableau utilisateur
    const [searchUsers, setSearchUsers] = useState("");
    const [searchOperateurs, setSearchOperateurs] = useState("");
    const [searchAdmins, setSearchAdmins] = useState("");

    // États pour afficher ou non les modales d'ajout/modification
    const [showAddModal, setShowAddModal] = useState(false);
    const [showEditModal, setShowEditModal] = useState(false);

    // Données du formulaire pour création d’un nouvel utilisateur
    const [newUser, setNewUser] = useState({
        nom: "",
        email: "",
        telephone: "",
        motDePasse: "",
        role: "OPERATEUR",
    });

    // Données du formulaire pour modification d’un utilisateur existant
    const [editUser, setEditUser] = useState(null);

    // Indicateur de chargement global (affiche disable sur boutons)
    const [loading, setLoading] = useState(false);

    // Messages d’erreur spécifiques pour ajout, modification, suppression
    const [errorAdd, setErrorAdd] = useState(null);
    const [errorEdit, setErrorEdit] = useState(null);
    const [errorDelete, setErrorDelete] = useState(null);

    /**
     * Récupère la liste complète des utilisateurs depuis le backend.
     * useCallback pour éviter de recréer la fonction à chaque render.
     */
    const fetchUsers = useCallback(async () => {
        try {
            const res = await fetch("/api/admin/users");
            if (!res.ok) throw new Error("Erreur de chargement");
            const data = await res.json();
            setAllUsers(data);
        } catch (err) {
            console.error(err);
        }
    }, []);

    // Appel initial pour charger les utilisateurs au montage du composant
    useEffect(() => {
        fetchUsers();
    }, [fetchUsers]);

    // Sélectionne un utilisateur quand on clique sur une ligne
    const handleSelect = (user) => setSelectedUser(user);

    /**
     * Supprime l’utilisateur sélectionné après confirmation.
     * Met à jour la liste des utilisateurs après suppression.
     */
    const handleDelete = async () => {
        setErrorDelete(null);
        if (!selectedUser) return;
        if (!window.confirm(`Confirmez-vous la suppression de ${selectedUser.nom} ?`))
            return;

        try {
            setLoading(true);
            const res = await fetch(`/api/admin/users/${selectedUser.id}`, {
                method: "DELETE",
            });
            if (!res.ok) throw new Error("Échec suppression");

            await fetchUsers();
            setSelectedUser(null);
            alert("Utilisateur supprimé");
        } catch (err) {
            setErrorDelete(err.message);
        } finally {
            setLoading(false);
        }
    };

    /**
     * Ouvre la modal de modification en préremplissant le formulaire avec les données de l’utilisateur sélectionné.
     */
    const handleModify = () => {
        if (!selectedUser) return;
        setEditUser({
            id: selectedUser.id,
            nom: selectedUser.nom || "",
            email: selectedUser.email || "",
            telephone: selectedUser.telephone || "",
            motDePasse: "",
            role: selectedUser.role || "USER",
        });
        setShowEditModal(true);
        setErrorEdit(null);
    };

    /**
     * Soumet la modification de l’utilisateur au backend via PUT.
     * Vérifie la présence des champs obligatoires avant envoi.
     * Actualise la liste après succès.
     */
    const handleEditSubmit = async () => {
        if (!editUser.nom || !editUser.email) {
            setErrorEdit("Champs requis manquants");
            return;
        }

        try {
            setLoading(true);
            const res = await fetch(`/api/admin/users/${editUser.id}`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(editUser),
            });
            if (!res.ok) throw new Error("Échec modification");

            await fetchUsers();
            setShowEditModal(false);
            setSelectedUser(null);
            alert("Utilisateur modifié");
        } catch (err) {
            setErrorEdit(err.message);
        } finally {
            setLoading(false);
        }
    };

    /**
     * Ajoute un nouvel utilisateur via POST.
     * Vérifie les champs obligatoires avant envoi.
     * Actualise la liste après succès.
     */
    const handleAddUser = async () => {
        if (!newUser.nom || !newUser.email || !newUser.motDePasse) {
            setErrorAdd("Tous les champs sont obligatoires");
            return;
        }

        try {
            setLoading(true);
            const res = await fetch("/api/admin/users", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(newUser),
            });
            if (!res.ok) throw new Error("Échec ajout");

            await fetchUsers();
            setShowAddModal(false);
            // Réinitialiser le formulaire d’ajout
            setNewUser({
                nom: "",
                email: "",
                telephone: "",
                motDePasse: "",
                role: "OPERATEUR",
            });
            alert("Utilisateur ajouté !");
        } catch (err) {
            setErrorAdd(err.message);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-gradient-to-r from-yellow-400 to-black flex items-center justify-center font-poppins p-6">
            <div className="bg-black bg-opacity-80 p-8 rounded-lg max-w-7xl w-full text-white relative">

                {/* Boutons de navigation et d’ajout */}
                <div className="mb-6 flex justify-between">
                    <button
                        onClick={() => navigate("/admin-dashboard")}
                        className="bg-gray-700 text-yellow-400 px-4 py-2 rounded hover:bg-gray-600"
                    >
                        ← Retour
                    </button>
                    <button
                        onClick={() => {
                            setErrorAdd(null);
                            setShowAddModal(true);
                        }}
                        className="bg-green-500 px-4 py-2 rounded font-semibold hover:bg-green-600"
                    >
                        + Ajouter un utilisateur
                    </button>
                </div>

                {/* Titre principal */}
                <h1 className="text-yellow-400 text-3xl font-bold text-center mb-10">
                    Gestion des Comptes
                </h1>

                {/* Tableaux utilisateurs par rôle */}
                <UserTable
                    title="Clients"
                    role="USER"
                    search={searchUsers}
                    setSearch={setSearchUsers}
                    users={allUsers}
                    selectedUser={selectedUser}
                    onSelect={handleSelect}
                />
                <UserTable
                    title="Opérateurs"
                    role="OPERATEUR"
                    search={searchOperateurs}
                    setSearch={setSearchOperateurs}
                    users={allUsers}
                    selectedUser={selectedUser}
                    onSelect={handleSelect}
                />
                <UserTable
                    title="Admins"
                    role="ADMIN"
                    search={searchAdmins}
                    setSearch={setSearchAdmins}
                    users={allUsers}
                    selectedUser={selectedUser}
                    onSelect={handleSelect}
                />

                {/* Affichage des actions pour l'utilisateur sélectionné */}
                {selectedUser && (
                    <div className="mt-10 bg-gray-800 p-6 rounded text-center">
                        <p className="mb-4">
                            Utilisateur sélectionné :{" "}
                            <strong>
                                {selectedUser.nom} ({selectedUser.role})
                            </strong>
                        </p>
                        {/* Message d’erreur possible lors de la suppression */}
                        {errorDelete && (
                            <p className="text-red-500 mb-2">{errorDelete}</p>
                        )}
                        <div className="flex justify-center gap-6">
                            <button
                                onClick={handleModify}
                                className="bg-yellow-400 text-black px-6 py-2 rounded hover:bg-yellow-500 font-semibold"
                                disabled={loading}
                            >
                                ✏️ Modifier
                            </button>
                            <button
                                onClick={handleDelete}
                                className="bg-red-600 text-white px-6 py-2 rounded hover:bg-red-700 font-semibold"
                                disabled={loading}
                            >
                                🗑️ Supprimer
                            </button>
                        </div>
                    </div>
                )}

                {/* Modal ajout utilisateur */}
                {showAddModal && (
                    <Modal
                        title="Ajouter un utilisateur"
                        onClose={() => setShowAddModal(false)}
                    >
                        {errorAdd && <p className="text-red-600 mb-2">{errorAdd}</p>}
                        <input
                            className="w-full mb-2 p-2 border rounded text-black"
                            placeholder="Nom"
                            value={newUser.nom}
                            onChange={(e) =>
                                setNewUser({ ...newUser, nom: e.target.value })
                            }
                            autoFocus
                        />
                        <input
                            className="w-full mb-2 p-2 border rounded text-black"
                            placeholder="Email"
                            type="email"
                            value={newUser.email}
                            onChange={(e) =>
                                setNewUser({ ...newUser, email: e.target.value })
                            }
                        />
                        <input
                            className="w-full mb-2 p-2 border rounded text-black"
                            placeholder="Téléphone"
                            value={newUser.telephone}
                            onChange={(e) =>
                                setNewUser({ ...newUser, telephone: e.target.value })
                            }
                        />
                        <input
                            className="w-full mb-2 p-2 border rounded text-black"
                            placeholder="Mot de passe"
                            type="password"
                            value={newUser.motDePasse}
                            onChange={(e) =>
                                setNewUser({ ...newUser, motDePasse: e.target.value })
                            }
                        />
                        <select
                            className="w-full mb-4 p-2 border rounded text-black"
                            value={newUser.role}
                            onChange={(e) =>
                                setNewUser({ ...newUser, role: e.target.value })
                            }
                        >
                            <option value="OPERATEUR">Opérateur</option>
                            <option value="ADMIN">Admin</option>
                            <option value="USER">Client</option>
                        </select>
                        <div className="flex justify-between">
                            <button
                                className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
                                onClick={handleAddUser}
                                disabled={loading}
                            >
                                Ajouter
                            </button>
                            <button
                                className="text-gray-600 underline"
                                onClick={() => setShowAddModal(false)}
                            >
                                Annuler
                            </button>
                        </div>
                    </Modal>
                )}

                {/* Modal modification utilisateur */}
                {showEditModal && editUser && (
                    <Modal
                        title="Modifier l'utilisateur"
                        onClose={() => setShowEditModal(false)}
                    >
                        {errorEdit && <p className="text-red-600 mb-2">{errorEdit}</p>}
                        <input
                            className="w-full mb-2 p-2 border rounded text-black"
                            value={editUser.nom}
                            onChange={(e) => setEditUser({ ...editUser, nom: e.target.value })}
                            autoFocus
                        />
                        <input
                            className="w-full mb-2 p-2 border rounded text-black"
                            value={editUser.email}
                            onChange={(e) => setEditUser({ ...editUser, email: e.target.value })}
                            type="email"
                        />
                        <input
                            className="w-full mb-2 p-2 border rounded text-black"
                            value={editUser.telephone}
                            onChange={(e) => setEditUser({ ...editUser, telephone: e.target.value })}
                        />
                        <input
                            className="w-full mb-2 p-2 border rounded text-black"
                            type="password"
                            placeholder="Mot de passe (optionnel)"
                            value={editUser.motDePasse}
                            onChange={(e) => setEditUser({ ...editUser, motDePasse: e.target.value })}
                        />
                        <select
                            className="w-full mb-4 p-2 border rounded text-black"
                            value={editUser.role}
                            onChange={(e) => setEditUser({ ...editUser, role: e.target.value })}
                        >
                            <option value="OPERATEUR">Opérateur</option>
                            <option value="ADMIN">Admin</option>
                            <option value="USER">Client</option>
                        </select>
                        <div className="flex justify-between">
                            <button
                                className="bg-yellow-500 text-black px-4 py-2 rounded hover:bg-yellow-600"
                                onClick={handleEditSubmit}
                                disabled={loading}
                            >
                                Enregistrer
                            </button>
                            <button
                                className="text-gray-600 underline"
                                onClick={() => setShowEditModal(false)}
                            >
                                Annuler
                            </button>
                        </div>
                    </Modal>
                )}
            </div>
        </div>
    );
}

export default AdminUsers;
