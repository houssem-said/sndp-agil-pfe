import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";

/**
 * Composant principal du tableau de bord Admin
 * Permet la gestion complète des agences et des guichets associés,
 * ainsi que la gestion des opérateurs assignés aux guichets.
 */
function AdminDashboard() {
    const navigate = useNavigate();

    // Liste des agences chargées depuis le backend
    const [agences, setAgences] = useState([]);
    // Agence actuellement sélectionnée dans l'interface (objet complet)
    const [selectedAgence, setSelectedAgence] = useState(null);

    // Formulaire de modification d'un guichet (contient ses données)
    const [formGuichet, setFormGuichet] = useState({
        id: null,
        nom: "",
        ouvert: false,
        operateurId: "",
    });
    // Formulaire d'ajout d'un nouveau guichet
    const [newGuichet, setNewGuichet] = useState({
        nom: "",
        ouvert: false,
        operateurId: "",
    });

    // Formulaire de modification d'une agence
    const [editAgence, setEditAgence] = useState({ id: null, nom: "", adresse: "" });
    // Formulaire d'ajout d'une nouvelle agence
    const [newAgence, setNewAgence] = useState({ nom: "", adresse: "" });

    // Flags d'affichage des modals ou sections d'ajout/modification
    const [showAddAgence, setShowAddAgence] = useState(false);
    const [showEditAgence, setShowEditAgence] = useState(false);
    const [showAddGuichet, setShowAddGuichet] = useState(false);
    const [showEditGuichet, setShowEditGuichet] = useState(false);

    // Liste des opérateurs chargée depuis le backend (pour assignation aux guichets)
    const [operateurs, setOperateurs] = useState([]);

    // Gestion du menu utilisateur (ex : déconnexion)
    const [submenuOpen, setSubmenuOpen] = useState(false);
    const submenuRef = useRef(null);

    /**
     * useEffect appelé au montage du composant,
     * charge la liste des agences et des opérateurs
     */
    useEffect(() => {
        fetchAgences();
        fetchOperateurs();
    }, []);

    /**
     * Gestion du clic en dehors du menu utilisateur pour fermer le sous-menu
     */
    useEffect(() => {
        function handleClickOutside(event) {
            if (submenuRef.current && !submenuRef.current.contains(event.target)) {
                setSubmenuOpen(false);
            }
        }
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    /**
     * Déconnecte l'utilisateur en supprimant ses infos du localStorage
     * puis redirige vers la page de login
     */
    const handleLogout = () => {
        localStorage.removeItem("user");
        navigate("/login");
    };

    /**
     * Charge la liste complète des agences via l'API
     * Actualise la sélection courante si l'agence existe toujours
     */
    const fetchAgences = async () => {
        try {
            const res = await fetch("/api/agences");
            if (!res.ok) throw new Error("Erreur lors du chargement des agences");
            const data = await res.json();
            setAgences(data);
            // Met à jour la sélection d'agence si elle existe dans la nouvelle liste
            if (selectedAgence) {
                const updated = data.find((a) => a.id === selectedAgence.id);
                setSelectedAgence(updated || null);
            }
        } catch (err) {
            alert(err.message);
        }
    };

    /**
     * Charge la liste des opérateurs via l'API
     * Utilisée notamment pour assigner un opérateur à un guichet
     */
    const fetchOperateurs = async () => {
        try {
            const res = await fetch("/api/users/operateurs");
            if (!res.ok) throw new Error("Erreur lors du chargement des opérateurs");
            const data = await res.json();
            setOperateurs(Array.isArray(data) ? data : []);
        } catch (err) {
            alert(err.message);
        }
    };

    /**
     * Sélectionne une agence en fonction de son ID
     * Charge ses détails complets depuis l'API et met à jour l'état
     * @param {number} id - ID de l'agence sélectionnée
     */
    const selectAgence = async (id) => {
        try {
            const res = await fetch(`/api/agences/${id}`);
            if (!res.ok) throw new Error("Erreur chargement agence");
            const data = await res.json();
            setSelectedAgence(data);
        } catch (err) {
            alert(err.message);
        }
    };

    /**
     * Supprime une agence après confirmation utilisateur
     * Recharge la liste des agences et réinitialise la sélection
     * @param {number} id - ID de l'agence à supprimer
     */
    const deleteAgence = async (id) => {
        if (!window.confirm("Supprimer cette agence ?")) return;
        try {
            const res = await fetch(`/api/agences/${id}`, { method: "DELETE" });
            if (!res.ok) throw new Error("Erreur lors de la suppression");
            alert("Agence supprimée");
            await fetchAgences();
            setSelectedAgence(null);
        } catch (err) {
            alert(err.message);
        }
    };

    /**
     * Ajoute une nouvelle agence après validation des champs
     * Recharge la liste des agences et ferme la fenêtre d'ajout
     */
    const saveNewAgence = async () => {
        if (!newAgence.nom.trim() || !newAgence.adresse.trim()) {
            alert("Nom et adresse obligatoires");
            return;
        }
        try {
            const res = await fetch("/api/agences", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(newAgence),
            });
            if (!res.ok) throw new Error("Erreur lors de l'ajout");
            alert("Agence ajoutée");
            setShowAddAgence(false);
            setNewAgence({ nom: "", adresse: "" });
            await fetchAgences();
        } catch (err) {
            alert(err.message);
        }
    };

    /**
     * Modifie une agence existante après validation des champs
     * Recharge la liste des agences et la sélection actuelle si nécessaire
     */
    const saveEditAgence = async () => {
        if (!editAgence.nom.trim() || !editAgence.adresse.trim()) {
            alert("Nom et adresse obligatoires");
            return;
        }
        try {
            const res = await fetch(`/api/agences/${editAgence.id}`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ nom: editAgence.nom, adresse: editAgence.adresse }),
            });
            if (!res.ok) throw new Error("Erreur lors de la modification");
            alert("Agence modifiée");
            setShowEditAgence(false);
            await fetchAgences();
            if (selectedAgence && selectedAgence.id === editAgence.id) {
                await selectAgence(editAgence.id);
            }
        } catch (err) {
            alert(err.message);
        }
    };

    /**
     * Supprime un guichet après confirmation utilisateur
     * Recharge la sélection d'agence pour rafraîchir la liste des guichets
     * @param {number} id - ID du guichet à supprimer
     */
    const deleteGuichet = async (id) => {
        if (!window.confirm("Supprimer ce guichet ?")) return;
        try {
            const res = await fetch(`/api/guichets/${id}`, { method: "DELETE" });
            if (!res.ok) throw new Error("Erreur lors de la suppression");
            alert("Guichet supprimé");
            if (selectedAgence) await selectAgence(selectedAgence.id);
        } catch (err) {
            alert(err.message);
        }
    };

    /**
     * Ajoute un nouveau guichet associé à l'agence sélectionnée
     * Valide le nom, recharge la sélection et ferme la fenêtre d'ajout
     */
    const saveNewGuichet = async () => {
        if (!newGuichet.nom.trim()) {
            alert("Nom du guichet obligatoire");
            return;
        }
        try {
            const res = await fetch("/api/guichets", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    nom: newGuichet.nom,
                    ouvert: newGuichet.ouvert,
                    agence: { id: selectedAgence?.id },
                    operateur: newGuichet.operateurId ? { id: Number(newGuichet.operateurId) } : null,
                }),
            });
            if (!res.ok) throw new Error("Erreur lors de l'ajout du guichet");
            alert("Guichet ajouté");
            setShowAddGuichet(false);
            setNewGuichet({ nom: "", ouvert: false, operateurId: "" });
            if (selectedAgence) await selectAgence(selectedAgence.id);
        } catch (err) {
            alert(err.message);
        }
    };

    /**
     * Modifie un guichet existant avec les données du formulaire
     * Recharge la sélection d'agence pour rafraîchir la liste des guichets
     */
    const saveEditGuichet = async () => {
        if (!formGuichet.nom.trim()) {
            alert("Nom du guichet obligatoire");
            return;
        }
        try {
            const res = await fetch(`/api/guichets/${formGuichet.id}`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    nom: formGuichet.nom,
                    ouvert: formGuichet.ouvert,
                    agence: { id: selectedAgence?.id },
                    operateur: formGuichet.operateurId ? { id: Number(formGuichet.operateurId) } : null,
                }),
            });
            if (!res.ok) throw new Error("Erreur lors de la modification du guichet");
            alert("Guichet modifié");
            setShowEditGuichet(false);
            if (selectedAgence) await selectAgence(selectedAgence.id);
        } catch (err) {
            alert(err.message);
        }
    };

    return (
        <div className="flex min-h-screen bg-gradient-to-r from-yellow-400 to-black text-white font-poppins">
            <aside className="w-60 bg-black bg-opacity-90 p-8 flex flex-col space-y-4">
                <h2 className="text-yellow-400 text-2xl">Admin</h2>
                <button className="text-left text-yellow-400 font-semibold" onClick={fetchAgences}>
                    📊 Tableau de bord
                </button>
                <button className="text-left hover:text-yellow-300" onClick={() => navigate("/admin-users")}>
                    👥 Gérer les comptes
                </button>
                <button className="text-left hover:text-yellow-300" onClick={() => navigate("/admin-profile")}>
                    🔐 Mon profil
                </button>
            </aside>

            <main className="flex-1 p-8 relative">
                {/* Menu utilisateur avec déconnexion */}
                <div className="absolute top-5 right-5 cursor-pointer select-none" ref={submenuRef}>
                        <span
                            className="bg-gray-900 bg-opacity-80 px-4 py-2 rounded text-yellow-400 font-semibold"
                            onClick={() => setSubmenuOpen(!submenuOpen)}
                        >
                            👤 Admin ▾
                        </span>
                    {submenuOpen && (
                        <div className="absolute right-0 mt-2 w-36 bg-gray-900 rounded shadow-lg overflow-hidden z-50">
                            <button
                                className="w-full text-left px-4 py-2 text-sm hover:bg-yellow-400 hover:text-black"
                                onClick={handleLogout}
                            >
                                Déconnexion
                            </button>
                        </div>
                    )}
                </div>

                <div className="flex flex-col mb-6">
                    <h1 className="text-3xl text-yellow-400 mb-4">Gestion des Agences & Guichets</h1>
                    <button
                        className="bg-green-600 px-4 py-2 rounded self-start"
                        onClick={() => setShowAddAgence(true)}
                        style={{ marginTop: "1rem" }}
                    >
                        + Ajouter agence
                    </button>
                </div>

                <table className="mb-6 w-full text-left border-collapse bg-gray-900 rounded">
                    <thead>
                    <tr className="border-b border-yellow-400 text-yellow-400">
                        <th className="p-2">Nom</th>
                        <th className="p-2">Adresse</th>
                        <th className="p-2">Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    {agences.map((a) => (
                        <tr key={a.id} className="hover:bg-yellow-400 hover:text-black">
                            <td className="p-2 cursor-pointer" onClick={() => selectAgence(a.id)}>
                                {a.nom}
                            </td>
                            <td className="p-2">{a.adresse}</td>
                            <td className="p-2 space-x-2">
                                <button
                                    className="bg-yellow-500 px-2 rounded"
                                    onClick={() => {
                                        setEditAgence(a);
                                        setShowEditAgence(true);
                                    }}
                                >
                                    ✏️
                                </button>
                                <button className="bg-red-600 px-2 rounded" onClick={() => deleteAgence(a.id)}>
                                    🗑️
                                </button>
                            </td>
                        </tr>
                    ))}
                    </tbody>
                </table>

                {selectedAgence && (
                    <section className="bg-gray-800 p-6 rounded">
                        <h2 className="text-xl text-yellow-300 mb-4">{selectedAgence.nom} → Guichets</h2>
                        <button className="bg-green-600 px-3 py-1 rounded mb-4" onClick={() => setShowAddGuichet(true)}>
                            + Ajouter guichet
                        </button>
                        <table className="w-full mb-4">
                            <thead>
                            <tr className="border-b border-yellow-300 text-yellow-300">
                                <th className="p-2">Nom</th>
                                <th className="p-2">Ouvert</th>
                                <th className="p-2">Opérateur</th>
                                <th className="p-2">Actions</th>
                            </tr>
                            </thead>
                            <tbody>
                            {selectedAgence.guichets?.map((g) => (
                                <tr key={g.id} className="hover:bg-yellow-400 hover:text-black">
                                    <td className="p-2">{g.nom}</td>
                                    <td className="p-2">{g.ouvert ? "Oui" : "Non"}</td>
                                    <td className="p-2">
                                        {g.operateur ? `${g.operateur.nom} (${g.operateur.email})` : "Non assigné"}
                                    </td>
                                    <td className="p-2 space-x-2">
                                        <button
                                            className="bg-yellow-500 px-2 rounded"
                                            onClick={() => {
                                                setFormGuichet({
                                                    id: g.id,
                                                    nom: g.nom,
                                                    ouvert: g.ouvert,
                                                    operateurId: g.operateur?.id || "",
                                                });
                                                setShowEditGuichet(true);
                                            }}
                                        >
                                            ✏️
                                        </button>
                                        <button className="bg-red-600 px-2 rounded" onClick={() => deleteGuichet(g.id)}>
                                            🗑️
                                        </button>
                                    </td>
                                </tr>
                            ))}
                            </tbody>
                        </table>
                    </section>
                )}

                {showAddAgence && (
                    <Modal title="Nouvelle Agence" onClose={() => setShowAddAgence(false)}>
                        <input
                            value={newAgence.nom}
                            onChange={(e) => setNewAgence({ ...newAgence, nom: e.target.value })}
                            className="mb-2 p-2 w-full text-black"
                            placeholder="Nom"
                        />
                        <input
                            value={newAgence.adresse}
                            onChange={(e) => setNewAgence({ ...newAgence, adresse: e.target.value })}
                            className="mb-4 p-2 w-full text-black"
                            placeholder="Adresse"
                        />
                        <div className="flex justify-end gap-2">
                            <button className="bg-gray-600 px-4 py-2 rounded" onClick={() => setShowAddAgence(false)}>
                                Annuler
                            </button>
                            <button className="bg-green-600 px-4 py-2 rounded" onClick={saveNewAgence}>
                                Ajouter
                            </button>
                        </div>
                    </Modal>
                )}

                {showEditAgence && (
                    <Modal title="Modifier Agence" onClose={() => setShowEditAgence(false)}>
                        <input
                            value={editAgence.nom}
                            onChange={(e) => setEditAgence({ ...editAgence, nom: e.target.value })}
                            className="mb-2 p-2 w-full text-black"
                            placeholder="Nom"
                        />
                        <input
                            value={editAgence.adresse}
                            onChange={(e) => setEditAgence({ ...editAgence, adresse: e.target.value })}
                            className="mb-4 p-2 w-full text-black"
                            placeholder="Adresse"
                        />
                        <div className="flex justify-end gap-2">
                            <button className="bg-gray-600 px-4 py-2 rounded" onClick={() => setShowEditAgence(false)}>
                                Annuler
                            </button>
                            <button className="bg-yellow-500 px-4 py-2 rounded" onClick={saveEditAgence}>
                                Enregistrer
                            </button>
                        </div>
                    </Modal>
                )}

                {showAddGuichet && (
                    <Modal title="Nouveau Guichet" onClose={() => setShowAddGuichet(false)}>
                        <input
                            value={newGuichet.nom}
                            onChange={(e) => setNewGuichet({ ...newGuichet, nom: e.target.value })}
                            className="mb-2 p-2 w-full text-black"
                            placeholder="Nom"
                        />
                        <label className="flex items-center mb-2">
                            <input
                                type="checkbox"
                                className="mr-2"
                                checked={newGuichet.ouvert}
                                onChange={(e) => setNewGuichet({ ...newGuichet, ouvert: e.target.checked })}
                            />
                            Ouvert à l'ouverture
                        </label>
                        <label className="block mb-2 text-sm">Affecter à un opérateur :</label>
                        <select
                            className="mb-4 p-2 w-full text-black"
                            value={newGuichet.operateurId}
                            onChange={(e) => setNewGuichet({ ...newGuichet, operateurId: e.target.value })}
                        >
                            <option value="">-- Aucun --</option>
                            {operateurs.map((op) => (
                                <option key={op.id} value={op.id}>
                                    {op.nom} ({op.email})
                                </option>
                            ))}
                        </select>
                        <div className="flex justify-end gap-2">
                            <button className="bg-gray-600 px-4 py-2 rounded" onClick={() => setShowAddGuichet(false)}>
                                Annuler
                            </button>
                            <button className="bg-green-600 px-4 py-2 rounded" onClick={saveNewGuichet}>
                                Ajouter
                            </button>
                        </div>
                    </Modal>
                )}

                {showEditGuichet && (
                    <Modal title="Modifier Guichet" onClose={() => setShowEditGuichet(false)}>
                        <input
                            value={formGuichet.nom}
                            onChange={(e) => setFormGuichet({ ...formGuichet, nom: e.target.value })}
                            className="mb-2 p-2 w-full text-black"
                            placeholder="Nom"
                        />
                        <label className="flex items-center mb-2">
                            <input
                                type="checkbox"
                                className="mr-2"
                                checked={formGuichet.ouvert}
                                onChange={(e) => setFormGuichet({ ...formGuichet, ouvert: e.target.checked })}
                            />
                            Ouvert à l'ouverture
                        </label>
                        <label className="block mb-2 text-sm">Changer d’opérateur :</label>
                        <select
                            className="mb-4 p-2 w-full text-black"
                            value={formGuichet.operateurId}
                            onChange={(e) => setFormGuichet({ ...formGuichet, operateurId: e.target.value })}
                        >
                            <option value="">-- Aucun --</option>
                            {operateurs.map((op) => (
                                <option key={op.id} value={op.id}>
                                    {op.nom} ({op.email})
                                </option>
                            ))}
                        </select>
                        <div className="flex justify-end gap-2">
                            <button className="bg-gray-600 px-4 py-2 rounded" onClick={() => setShowEditGuichet(false)}>
                                Annuler
                            </button>
                            <button className="bg-yellow-500 px-4 py-2 rounded" onClick={saveEditGuichet}>
                                Enregistrer
                            </button>
                        </div>
                    </Modal>
                )}
            </main>
        </div>
    );
}

// Modal générique
function Modal({ children, title, onClose }) {
    return (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
            <div className="bg-gray-900 rounded-lg p-6 w-96 max-w-full text-white relative">
                <h3 className="text-xl mb-4">{title}</h3>
                {children}
                <button
                    className="absolute top-2 right-2 text-yellow-400 text-xl font-bold"
                    onClick={onClose}
                    aria-label="Fermer"
                >
                    ×
                </button>
            </div>
        </div>
    );
}

export default AdminDashboard;

